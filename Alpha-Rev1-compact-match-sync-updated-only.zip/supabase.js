/* ============================================================
   SUPABASE SERVICE LAYER — Proxied via Cloudflare Worker
   All DB calls go to YOUR_WORKER_DOMAIN/db/*
   No Supabase URL or keys in this file.
   ============================================================ */

const WORKER_URL = 'https://scs-app.karikalan-indo.workers.dev'; // ← replace with your Cloudflare Worker domain

// ─────────────────────────────────────────────────────────────
//  DATE HELPERS — always use local time (not UTC)
// ─────────────────────────────────────────────────────────────
/** Returns today's date as "YYYY-MM-DD" in the device's local timezone */
function localDateStr(date = new Date()) {
  const y  = date.getFullYear();
  const m  = String(date.getMonth() + 1).padStart(2, '0');
  const d  = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}
/** Returns an ISO-like timestamp "YYYY-MM-DDTHH:mm:ss" in local time */
function localISOString(date = new Date()) {
  const y   = date.getFullYear();
  const mo  = String(date.getMonth() + 1).padStart(2, '0');
  const d   = String(date.getDate()).padStart(2, '0');
  const h   = String(date.getHours()).padStart(2, '0');
  const mi  = String(date.getMinutes()).padStart(2, '0');
  const s   = String(date.getSeconds()).padStart(2, '0');
  return `${y}-${mo}-${d}T${h}:${mi}:${s}`;
}

// Cache keys
const CACHE_PLAYERS   = 'kbrr_cache_players';
const CACHE_TIMESTAMP = 'kbrr_cache_ts';
const CACHE_TTL_MS    = 5 * 60 * 1000; // 5 minutes

// ─────────────────────────────────────────────────────────────
//  WORKER HELPERS — these replace all direct Supabase calls
// ─────────────────────────────────────────────────────────────

/* ── Global DB loading spinner ── */
var _dbBusyCount = 0;

function _dbBusyShow() {
  _dbBusyCount++;
  var el = document.getElementById('scs-db-spinner');
  if (!el) {
    el = document.createElement('div');
    el.id = 'scs-db-spinner';
    el.style.cssText = [
      'position:fixed',
      'top:0','left:0','right:0',
      'height:3px',
      'background:linear-gradient(90deg,#6c63ff,#2dce89,#6c63ff)',
      'background-size:200% 100%',
      'animation:scs-db-bar 1.2s linear infinite',
      'z-index:999999',
      'border-radius:0 0 2px 2px',
      'transition:opacity 0.2s'
    ].join(';');
    // Inject keyframes once
    if (!document.getElementById('scs-db-spinner-style')) {
      var style = document.createElement('style');
      style.id = 'scs-db-spinner-style';
      style.textContent = '@keyframes scs-db-bar{0%{background-position:200% 0}100%{background-position:-200% 0}}';
      document.head.appendChild(style);
    }
    document.body.appendChild(el);
  }
  el.style.opacity = '1';
  el.style.display = 'block';
}

function _dbBusyHide() {
  _dbBusyCount = Math.max(0, _dbBusyCount - 1);
  if (_dbBusyCount === 0) {
    var el = document.getElementById('scs-db-spinner');
    if (el) {
      el.style.opacity = '0';
      setTimeout(function() { if (_dbBusyCount === 0 && el.parentNode) el.style.display = 'none'; }, 200);
    }
  }
}

async function _sbFetch(url, body) {
  await window.SCSRoundStorage?.waitForNetwork();
  _dbBusyShow();
  try {
    const secureBody = Object.assign({}, body || {});
    if (secureBody.table) {
      const user = typeof authGetUser === 'function' ? authGetUser() : null;
      const token = typeof _getLocalToken === 'function' ? _getLocalToken() : null;
      if (user && user.id) secureBody.userAccountId = user.id;
      if (token) secureBody.sessionToken = token;
    }
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(secureBody)
    });
    return res;
  } finally {
    _dbBusyHide();
  }
}

const SCS_PRACTICE_MIRROR_TABLES = new Set(['clubs','players','memberships','sessions','matches','slots','slot_claims']);
const SCS_PRACTICE_OFFLINE_WRITABLE = new Set(['players','memberships','sessions','matches','slot_claims']);

function _scsPracticeCanMirror(table) {
  return SCS_PRACTICE_MIRROR_TABLES.has(String(table || '')) && window.SCSOfflineDB;
}

function _scsPracticeCanWriteOffline(table) {
  return SCS_PRACTICE_OFFLINE_WRITABLE.has(String(table || '')) && window.SCSOfflineDB;
}

function _scsPracticeUuid() {
  return (window.crypto && typeof window.crypto.randomUUID === 'function')
    ? window.crypto.randomUUID() : 'practice-' + Date.now() + '-' + Math.random().toString(16).slice(2);
}

function _scsPracticeWithIds(data) {
  const rows = (Array.isArray(data) ? data : [data]).map(function(row) {
    const next = Object.assign({}, row || {});
    if (next.id == null) next.id = _scsPracticeUuid();
    return next;
  });
  return Array.isArray(data) ? rows : rows[0];
}

function _scsPracticeQueryParts(query) {
  const params = new URLSearchParams(String(query || '').replace(/^\?/, ''));
  const controls = new Set(['select','order','limit','offset']);
  const filters = [];
  params.forEach(function(value, key) {
    if (!controls.has(key)) filters.push({ key:key, value:value });
  });
  return { params:params, filters:filters };
}

function _scsPracticeRowMatches(row, filters) {
  return filters.every(function(filter) {
    const raw = String(filter.value || '');
    const dot = raw.indexOf('.');
    const op = dot < 0 ? 'eq' : raw.slice(0, dot);
    const expected = dot < 0 ? raw : raw.slice(dot + 1);
    const actual = row && row[filter.key];
    if (op === 'eq') return String(actual) === expected;
    if (op === 'neq') return String(actual) !== expected;
    if (op === 'is') return expected === 'null' ? actual == null : String(actual) === expected;
    if (op === 'in') return expected.replace(/^\(|\)$/g, '').split(',').map(String).includes(String(actual));
    if (op === 'ilike') {
      const needle = expected.replace(/^%|%$/g, '').toLocaleLowerCase();
      return String(actual == null ? '' : actual).toLocaleLowerCase().includes(needle);
    }
    return false;
  });
}

async function _scsPracticeLocalRows(table, query) {
  if (!_scsPracticeCanMirror(table) || typeof SCSOfflineDB.getTableRows !== 'function') return [];
  const parsed = _scsPracticeQueryParts(query);
  let rows = await SCSOfflineDB.getTableRows(table);
  rows = rows.filter(function(row) { return _scsPracticeRowMatches(row, parsed.filters); });
  const order = parsed.params.get('order');
  if (order) {
    const pieces = order.split('.'), field = pieces[0], desc = pieces[1] === 'desc';
    rows.sort(function(a,b) { const x=a&&a[field], y=b&&b[field]; return (x===y?0:(x>y?1:-1))*(desc?-1:1); });
  }
  const limit = Number(parsed.params.get('limit'));
  if (limit > 0) rows = rows.slice(0, limit);
  return rows;
}

async function _scsPracticeMirrorRows(table, rows) {
  if (!_scsPracticeCanMirror(table) || typeof SCSOfflineDB.saveTableRows !== 'function') return;
  const list = Array.isArray(rows) ? rows : (rows ? [rows] : []);
  if (list.length) await SCSOfflineDB.saveTableRows(table, list);
}

async function _scsPracticeQueue(method, table, query, data, extra) {
  if (!_scsPracticeCanWriteOffline(table) || typeof SCSOfflineDB.enqueuePracticeOperation !== 'function') return null;
  const operation = await SCSOfflineDB.enqueuePracticeOperation(Object.assign({
    method:method, table:table, query:query || '', data:data || null,
    club_id:(data && !Array.isArray(data) && data.club_id) || null
  }, extra || {}));
  window.dispatchEvent(new CustomEvent('scs:practice-sync-pending', { detail:{ operationId:operation.operation_id } }));
  return operation;
}

async function _scsPracticeApplyLocalPatch(table, query, data) {
  const rows = await _scsPracticeLocalRows(table, query);
  const changed = rows.map(function(row) { return Object.assign({}, row, data || {}); });
  await _scsPracticeMirrorRows(table, changed);
  return changed;
}

async function _scsPracticeApplyLocalDelete(table, query) {
  const rows = await _scsPracticeLocalRows(table, query);
  if (typeof SCSOfflineDB.deleteTableRow === 'function') {
    await Promise.all(rows.map(function(row) { return SCSOfflineDB.deleteTableRow(table, row.id); }));
  }
  return rows;
}

async function _scsPracticeRemoteMutation(operation) {
  const method = operation.method;
  const endpoint = method === 'post' ? 'upsert' : method;
  const body = { table:operation.table, query:operation.query || '', data:operation.data };
  if (method === 'post') body.onConflict = 'id';
  if (operation.prefer) body.prefer = operation.prefer;
  if (operation.onConflict) body.onConflict = operation.onConflict;
  const res = await _sbFetch(WORKER_URL + '/db/' + endpoint, body);
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || (method.toUpperCase() + ' ' + operation.table + ' failed'));
  }
  return res.json();
}

async function scsFlushPracticeOutbox() {
  if (navigator.onLine === false || !window.SCSOfflineDB || typeof SCSOfflineDB.getPracticeOperations !== 'function') return false;
  const operations = await SCSOfflineDB.getPracticeOperations('pending');
  for (const operation of operations.sort(function(a,b) { return String(a.created_at).localeCompare(String(b.created_at)); })) {
    try {
      const result = await _scsPracticeRemoteMutation(operation);
      await _scsPracticeMirrorRows(operation.table, result);
      await SCSOfflineDB.completePracticeOperation(operation.operation_id);
    } catch (error) {
      await SCSOfflineDB.updatePracticeOperation(operation.operation_id, {
        attempts:Number(operation.attempts || 0) + 1,
        last_error:error && error.message ? error.message : String(error)
      });
      return false;
    }
  }
  if (operations.length) window.dispatchEvent(new CustomEvent('scs:practice-synced', { detail:{ count:operations.length } }));
  return true;
}
window.scsFlushPracticeOutbox = scsFlushPracticeOutbox;

// Share identical reads that are requested at the same time. Several screens use
// the same account, membership and slot data; without this guard one UI event can
// fan out into many identical Worker/Supabase reads.
async function scsMatchScoringPassword(action,tournamentId,matchKey,password){
 const user=typeof authGetUser==='function'?authGetUser():null;
 const token=typeof _getLocalToken==='function'?_getLocalToken():null;
 const res=await fetch(WORKER_URL+'/scoring-password',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,tournamentId,matchKey,password,userAccountId:user?.id,sessionToken:token})});
 const data=await res.json().catch(()=>({}));if(!res.ok)throw Error(data.error||'Password service unavailable');return action==='get'?data.password:action==='verify'?data:true;
}
window.scsMatchScoringPassword=scsMatchScoringPassword;
// Per-login, per-match memory only: never stored in tournament state or local storage.
const _scsScoringPasswords=new Map();
function _scsScoringPasswordKey(id,key){return [(typeof authGetUser==='function'?authGetUser()?.id:''),typeof _getLocalToken==='function'?_getLocalToken():'',id,key].join(':');}
window.SCSMatchPasswords={
 get:(id,key)=>_scsScoringPasswords.get(_scsScoringPasswordKey(id,key))||'',
 remember:(id,key,value)=>_scsScoringPasswords.set(_scsScoringPasswordKey(id,key),value),
 async authorize(id,key){let password='',checked=await scsMatchScoringPassword('verify',id,key,password);if(checked.valid)return true;if(!checked.protected)throw Error('Club access is required to score this match.');for(let attempt=0;attempt<3;attempt++){password=window.prompt(attempt?'Incorrect password. Enter the match scoring password:':'Enter the match scoring password:');if(!password)return false;checked=await scsMatchScoringPassword('verify',id,key,password);if(checked.valid){this.remember(id,key,password);return true;}}throw Error('Could not verify the match password. Please retry.');}
};

async function sbGet(table, query = '') {
  const appSport = window.SCSSportContext?.appModule==='tournaments' ? null : (window.SCSClubSport?.current() || window.SCSSportContext?.sport);
  const scopedClubs = table === 'clubs' && ['badminton','pickleball'].includes(appSport);
  if (scopedClubs) {
    const params = new URLSearchParams(query);
    params.append('sport', 'eq.' + appSport);
    const selection = params.get('select');
    if (selection && selection !== '*' && !selection.split(',').includes('sport')) params.set('select', selection + ',sport');
    query = params.toString();
  }
  const visibleRows = rows => { if(table==='clubs'&&Array.isArray(rows))window.SCSClubSport?.remember(rows); return scopedClubs && Array.isArray(rows) ? rows.filter(club => club.sport === appSport) : rows; };
  await window.SCSRoundStorage?.waitForNetwork();
  if (navigator.onLine === false && _scsPracticeCanMirror(table)) return visibleRows(await _scsPracticeLocalRows(table, query));
  let res;
  try { res = await _sbFetch(WORKER_URL + '/db/get', { table, query }); }
  catch (error) { if (_scsPracticeCanMirror(table)) return visibleRows(await _scsPracticeLocalRows(table, query)); throw error; }
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `GET ${table} failed: ${res.status}`);
  }
  const rows = visibleRows(await res.json());
  await _scsPracticeMirrorRows(table, rows);
  return rows;
}

async function sbPost(table, data, prefer = 'return=representation') {
  await window.SCSRoundStorage?.waitForNetwork();
  const localData = _scsPracticeCanMirror(table) ? _scsPracticeWithIds(data) : data;
  if (navigator.onLine === false && _scsPracticeCanWriteOffline(table)) {
    await _scsPracticeMirrorRows(table, localData);
    await _scsPracticeQueue('post', table, '', localData, { prefer:prefer });
    return Array.isArray(localData) ? localData : [localData];
  }
  let res;
  try { res = await _sbFetch(WORKER_URL + '/db/post', { table, data:localData, prefer }); }
  catch (error) {
    if (!_scsPracticeCanWriteOffline(table)) throw error;
    await _scsPracticeMirrorRows(table, localData); await _scsPracticeQueue('post', table, '', localData, { prefer:prefer });
    return Array.isArray(localData) ? localData : [localData];
  }
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `POST ${table} failed`);
  }
  const rows = await res.json(); await _scsPracticeMirrorRows(table, rows); return rows;
}

async function sbPatch(table, query, data, prefer, scoreRef) {
  await window.SCSRoundStorage?.waitForNetwork();
  if (navigator.onLine === false && _scsPracticeCanWriteOffline(table)) {
    const rows = await _scsPracticeApplyLocalPatch(table, query, data);
    await _scsPracticeQueue('patch', table, query, data, { prefer:prefer }); return rows;
  }
  let res;
  try {
    res = await _sbFetch(WORKER_URL + '/db/patch', { table, query, data, prefer, scoringPassword:scoreRef?window.SCSMatchPasswords.get(scoreRef.tournamentId,scoreRef.matchKey):undefined });
    if(['tournaments','sessions'].includes(table)&&res.status===403){
      const problem=await res.clone().json().catch(()=>({}));
      if(problem.code==='SCORING_PASSWORD_REQUIRED'){
        const password=window.prompt('Enter the match scoring password to save the score:');
        if(!password)throw Error('Score save cancelled: scoring password required');
        res=await _sbFetch(WORKER_URL + '/db/patch', { table, query, data, prefer, scoringPassword:password });
      }
    }
  }
  catch (error) {
    if (!_scsPracticeCanWriteOffline(table)) throw error;
    const rows = await _scsPracticeApplyLocalPatch(table, query, data);
    await _scsPracticeQueue('patch', table, query, data, { prefer:prefer }); return rows;
  }
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `PATCH ${table} failed`);
  }
  const rows = await res.json();
  if (Array.isArray(rows) && rows.length) await _scsPracticeMirrorRows(table, rows); else await _scsPracticeApplyLocalPatch(table, query, data);
  return rows;
}

async function sbDelete(table, query) {
  await window.SCSRoundStorage?.waitForNetwork();
  if (navigator.onLine === false && _scsPracticeCanWriteOffline(table)) {
    const rows = await _scsPracticeApplyLocalDelete(table, query);
    await _scsPracticeQueue('delete', table, query, null); return rows;
  }
  let res;
  try { res = await _sbFetch(WORKER_URL + '/db/delete', { table, query }); }
  catch (error) {
    if (!_scsPracticeCanWriteOffline(table)) throw error;
    const rows = await _scsPracticeApplyLocalDelete(table, query);
    await _scsPracticeQueue('delete', table, query, null); return rows;
  }
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `DELETE ${table} failed: ${res.status}`);
  }
  const rows = await res.json(); await _scsPracticeApplyLocalDelete(table, query); return rows;
}

async function sbUpsert(table, data, onConflict) {
  const localData = _scsPracticeCanMirror(table) ? _scsPracticeWithIds(data) : data;
  if (navigator.onLine === false && _scsPracticeCanWriteOffline(table)) {
    await _scsPracticeMirrorRows(table, localData);
    await _scsPracticeQueue('upsert', table, '', localData, { onConflict:onConflict });
    return Array.isArray(localData) ? localData : [localData];
  }
  let res;
  try { res = await _sbFetch(WORKER_URL + '/db/upsert', { table, data:localData, onConflict }); }
  catch (error) {
    if (!_scsPracticeCanWriteOffline(table)) throw error;
    await _scsPracticeMirrorRows(table, localData);
    await _scsPracticeQueue('upsert', table, '', localData, { onConflict:onConflict });
    return Array.isArray(localData) ? localData : [localData];
  }
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `UPSERT ${table} failed`);
  }
  const rows = await res.json(); await _scsPracticeMirrorRows(table, rows); return rows;
}

window.addEventListener('online', function() { scsFlushPracticeOutbox().catch(function() {}); });
setTimeout(function() { if (navigator.onLine !== false) scsFlushPracticeOutbox().catch(function() {}); }, 1500);

// ─────────────────────────────────────────────────────────────
//  TOURNAMENTS — local-first snapshots, shared through the club
// ─────────────────────────────────────────────────────────────
const SCS_TOURNAMENT_STATE_VERSION = 1;
const _scsTournamentSaveTimers = new Map();
const _scsTournamentSaveChains = new Map();
const _scsTournamentPending = new Map();
const _scsTournamentServerIds = new Map();
const _scsTournamentGeneration = new Map();
const _scsTournamentLocalKeys = {
  knockout:'scs_knockout_tournament_v94',
  group:'scs_group_tournament_ui_v1',
  team:'scs_team_tournament_v1'
};
function _scsTournamentCloudIdKey(clubId, format) {
  return `scs_tournament_cloud_id_${clubId}_${format}`;
}
function _scsTournamentClientId(state) {
  if (!state._scsClientTournamentId) {
    state._scsClientTournamentId = (typeof crypto !== 'undefined' && crypto.randomUUID)
      ? crypto.randomUUID() : 'scs-' + Date.now() + '-' + Math.random().toString(36).slice(2);
  }
  return state._scsClientTournamentId;
}
function _scsTournamentSaveKey(clubId,format,state) {
  return clubId + ':' + format + ':' + _scsTournamentClientId(state);
}
function _scsTournamentLocalIdentity(format,state,id) {
  const key=_scsTournamentLocalKeys[format];
  if (!key || !id) return;
  try {
    const current=JSON.parse(localStorage.getItem(key)||'null');
    if (current && current._scsClientTournamentId===state._scsClientTournamentId) {
      current._scsCloudTournamentId=id;
      localStorage.setItem(key,JSON.stringify(current));
    }
  } catch (_) {}
}
function _scsTournamentStatus(format, state) {
  if (state && (state.completed === true || state.status === 'completed')) return 'completed';
  if (format === 'group') return state && state.started ? 'live' : 'draft';
  if (format === 'team') return state && state.encounters && state.encounters.some(e => e.matches && e.matches.some(m => m.status !== 'pending')) ? 'live' : 'draft';
  return state && state.live === true ? 'live' : 'draft';
}

async function _scsSaveTournamentOnce(format, state, scoreRetry=0) {
  const club=getMyClub();
  if (!club?.id) return null;
  const user=typeof authGetUser==='function'?authGetUser():null;
  const key=_scsTournamentSaveKey(club.id,format,state);
  const idKey=_scsTournamentCloudIdKey(club.id,format);
  let id=state._scsCloudTournamentId||_scsTournamentServerIds.get(key)||'';
  // Queue saves work with cloned snapshots, so a cloud ID assigned to one
  // snapshot may not be present on the next one. Resolve the stable client ID
  // before inserting; otherwise every autosave creates another master/event.
  if(!id){
    const clientId=_scsTournamentClientId(state);
    const matches=await sbGet('tournaments',
      `club_id=eq.${encodeURIComponent(club.id)}&format=eq.${format}&state->>_scsClientTournamentId=eq.${encodeURIComponent(clientId)}&order=updated_at.desc&limit=1&select=id`
    ).catch(()=>[]);
    id=matches?.[0]?.id||'';
  }
  // A legacy format-wide ID is deliberately NOT used for new saves.
  let scoreBaseVersion=null;
  if(id&&window.SCSTournamentScores&&['group','team'].includes(format)){const latest=await sbGet('tournaments','id=eq.'+encodeURIComponent(id)+'&club_id=eq.'+encodeURIComponent(club.id)+'&select=state,updated_at&limit=1');if(latest?.[0]?.state){SCSTournamentScores.merge(format,state,latest[0].state);scoreBaseVersion=latest[0].updated_at;}}
  const now=new Date().toISOString();
  const status=_scsTournamentStatus(format,state);
  const payload={
    club_id:club.id,format,
    title:String(state.title||(format==='group'?'Group Tournament':format==='team'?'Team Tournament':'Tournament')).slice(0,120),
    status,state_version:SCS_TOURNAMENT_STATE_VERSION,
    state,created_by:user?.id||null,updated_at:now
  };
  if(status==='live')payload.started_at=state.startedAt||state.started_at||now;
  if(status==='completed')payload.completed_at=state.completedAt||state.completed_at||now;
  if(id) {
    // If a saved ID was removed remotely, do not silently create another tournament.
    const saved=await sbPatch('tournaments',`id=eq.${encodeURIComponent(id)}&club_id=eq.${encodeURIComponent(club.id)}`+(scoreBaseVersion?'&updated_at=eq.'+encodeURIComponent(scoreBaseVersion):''),payload,scoreBaseVersion?'return=representation':undefined);
    if(scoreBaseVersion&&(!Array.isArray(saved)||!saved.length)){if(scoreRetry<2)return _scsSaveTournamentOnce(format,state,scoreRetry+1);throw Error('Tournament changed while saving. Retry after syncing.');}
  } else {
    const rows=await sbPost('tournaments',payload);
    id=rows?.[0]?.id||'';
    if(!id)throw new Error('Tournament creation returned no ID.');
  }
  state._scsCloudTournamentId=id;
  _scsTournamentServerIds.set(key,id);
  _scsTournamentLocalIdentity(format,state,id);
  localStorage.setItem(idKey,id); // compatibility for legacy consumers
  return id;
}
function dbSaveTournamentState(format,state,options={}) {
  if(window.SCSTournamentLocal)return SCSTournamentLocal.saveTournament(format,state);
  if(!['knockout','group','team'].includes(format)||!state||typeof state!=='object')return Promise.resolve(null);
  const club=getMyClub();
  if(!club?.id)return Promise.reject(new Error('Select a club before saving the tournament.'));
  const key=_scsTournamentSaveKey(club.id,format,state);
  // Explicit saves must use the supplied current state, never a potentially stale queued snapshot.
  // Cancel the queued timer and discard its snapshot; serialized saves preserve write order.
  const timer=_scsTournamentSaveTimers.get(key);
  if(timer){clearTimeout(timer);_scsTournamentSaveTimers.delete(key);}
  _scsTournamentPending.delete(key);
  const explicitRevision=options.outboxRevision||_scsOutboxPut(key,format,JSON.parse(JSON.stringify(state)));
  const previous=_scsTournamentSaveChains.get(key)||Promise.resolve();
  const job=previous.catch(()=>{}).then(async()=>{
    const id=await _scsSaveTournamentOnce(format,state);
    if(id)state._scsCloudTournamentId=id;
    _scsOutboxClearIfSame(key,explicitRevision);
    return id;
  });
  _scsTournamentSaveChains.set(key,job);
  job.finally(()=>{if(_scsTournamentSaveChains.get(key)===job)_scsTournamentSaveChains.delete(key)}).catch(()=>{});
  return job;
}
/* Durable tournament outbox: an offline/failed save survives reload.
   Writes are serialized by dbSaveTournamentState; only successful server
   acknowledgements clear the queued snapshot. */
const SCS_TOURNAMENT_OUTBOX_KEY='scs_tournament_sync_outbox_v406';
function _scsOutboxRead(){try{return JSON.parse(localStorage.getItem(SCS_TOURNAMENT_OUTBOX_KEY)||'{}')||{}}catch(_){return {}}}
function _scsOutboxWrite(data){try{localStorage.setItem(SCS_TOURNAMENT_OUTBOX_KEY,JSON.stringify(data))}catch(e){console.warn('Tournament outbox storage:',e)}}
function _scsOutboxPut(key,format,snapshot){
 const box=_scsOutboxRead(),revision=Date.now()+'-'+Math.random().toString(36).slice(2);
 box[key]={format,state:snapshot,revision};_scsOutboxWrite(box);return revision;
}
function _scsOutboxClearIfSame(key,revision){
 const box=_scsOutboxRead();
 if(box[key]&&box[key].revision===revision){delete box[key];_scsOutboxWrite(box)}
}
function scsFlushTournamentCloudSaves(){
 if(window.SCSTournamentLocal)return SCSTournamentLocal.importLegacy().then(()=>SCSTournamentLocal.sync());
 const box=_scsOutboxRead();
 return Promise.all(Object.keys(box).map(async key=>{
  const item=box[key];if(!item||!item.state)return;
  const club=getMyClub();if(!club?.id||key.indexOf(club.id+':')!==0)return;
  try{await dbSaveTournamentState(item.format,item.state,{outboxRevision:item.revision})}
  catch(e){console.warn('Tournament sync pending:',e.message)}
 }));
}
function scsQueueTournamentCloudSave(format,state) {
 if(window.SCSTournamentLocal){return SCSTournamentLocal.saveTournament(format,state).catch(error=>console.error('Local tournament save failed:',error));}
 if(!['knockout','group','team'].includes(format)||!state||typeof state!=='object')return;
 const club=getMyClub();if(!club?.id)return;
 const key=_scsTournamentSaveKey(club.id,format,state);
 let snapshot;try{snapshot=JSON.parse(JSON.stringify(state))}catch(_){return}
 const revision=_scsOutboxPut(key,format,snapshot);
 _scsTournamentPending.set(key,snapshot);
 const previous=_scsTournamentSaveTimers.get(key);if(previous)clearTimeout(previous);
 _scsTournamentSaveTimers.set(key,setTimeout(async()=>{
  _scsTournamentSaveTimers.delete(key);
  const latest=_scsTournamentPending.get(key);
  if(!latest)return;
  _scsTournamentPending.delete(key);
  try{await dbSaveTournamentState(format,latest,{outboxRevision:revision})}
  catch(e){console.warn('Tournament cloud save pending retry:',e.message)}
 },700));
}
if(typeof window!=='undefined'){
 window.addEventListener('online',scsFlushTournamentCloudSaves);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)scsFlushTournamentCloudSaves()});
 setTimeout(scsFlushTournamentCloudSaves,2500);
}
function scsResetTournamentCloudIdentity(format) {
  const club=getMyClub();
  if(!club?.id||!['knockout','group','team'].includes(format))return;
  // Do not cancel in-flight saves for a different tournament.
  localStorage.removeItem(_scsTournamentCloudIdKey(club.id,format));
}
function scsGetTournamentCloudIdentity(format) {
  const club=getMyClub();
  if(!club?.id)return '';
  try{
    const state=JSON.parse(localStorage.getItem(_scsTournamentLocalKeys[format])||'null');
    return state?._scsCloudTournamentId||'';
  }catch(_){return ''}
}
async function dbLoadLatestTournament(format) {
  const club = getMyClub();
  if (!club || !club.id || !['knockout', 'group', 'team'].includes(format)) return null;
  const rows = await sbGet('tournaments',
    `club_id=eq.${encodeURIComponent(club.id)}&format=eq.${format}&status=in.(draft,live)&order=updated_at.desc&limit=1&select=id,format,status,state_version,state,updated_at`
  ).catch(() => []);
  const row = rows && rows[0];
  if (!row || Number(row.state_version || 1) > SCS_TOURNAMENT_STATE_VERSION || !row.state) return null;
  row.state._scsCloudTournamentId=row.id;
  _scsTournamentClientId(row.state);
  localStorage.setItem(_scsTournamentCloudIdKey(club.id, format), row.id);
  return row;
}

async function dbListClubTournaments(statuses = ['draft', 'live', 'completed']) {
  const club = getMyClub();
  if (!club || !club.id) return [];
  const safe = statuses.filter(s => ['draft', 'live', 'completed', 'archived'].includes(s));
  return sbGet('tournaments',
    `club_id=eq.${encodeURIComponent(club.id)}&status=in.(${safe.join(',')})&order=updated_at.desc&select=id,format,title,status,state_version,created_by,started_at,completed_at,updated_at,state`
  ).catch(() => []);
}

async function dbLoadTournamentById(id) {
  const club = getMyClub();
  if (!club || !club.id || !id) return null;
  const rows = await sbGet('tournaments',
    `id=eq.${encodeURIComponent(id)}&club_id=eq.${encodeURIComponent(club.id)}&select=id,format,title,status,state_version,state,updated_at&limit=1`
  ).catch(() => []);
  const row = rows && rows[0];
  if (!row || !row.state || Number(row.state_version || 1) > SCS_TOURNAMENT_STATE_VERSION) return null;
  if(row.format==='knockout'&&row.state._scsMainTournament){
    const family=await dbLoadKnockoutTournamentFamily(row.state._scsClientTournamentId||row.state.id);
    if(family)return family;
  }
  if(row.format==='group'&&row.state._scsMainTournament){
    const family=await dbLoadGroupTournamentFamily(row.state._scsClientTournamentId||row.state.id);
    if(family)return family;
  }
  return row;
}

// The knockout master is authoritative for event membership. Child rows hold
// bracket details, but only event IDs present in the newest master snapshot are
// hydrated. Historical/deleted child rows therefore remain recoverable without
// silently reappearing in the active tournament.
async function dbLoadKnockoutTournamentFamily(masterId) {
  const club=getMyClub();
  if(!club?.id||!masterId)return null;
  const rows=await sbGet('tournaments',
    `club_id=eq.${encodeURIComponent(club.id)}&format=in.(knockout,group)&order=updated_at.desc&select=id,format,title,status,state_version,created_by,started_at,completed_at,updated_at,state`
  ).catch(()=>[]);
  const masters=rows.filter(row=>row.state?._scsMainTournament&&String(row.state._scsClientTournamentId||row.state.id)===String(masterId));
  const masterRow=masters[0];
  if(!masterRow?.state)return null;
  const master=JSON.parse(JSON.stringify(masterRow.state));
  master._scsCloudTournamentId=masterRow.id;
  const wanted=new Set((Array.isArray(master.events)?master.events:[]).map(event=>String(event.id)));
  const eventStates=[];
  for(const event of (master.events||[])){
    const eventId=String(event.id);
    const child=rows.find(row=>{
      const state=row.state||{};
      if(state._scsMainTournament||state._scsGroupKnockoutStage!=null||row.format!==(event.format||'knockout'))return false;
      const parent=state._scsParentTournamentId||state._scsKoMainId||'';
      const childId=state._scsKoEventId||state._scsGroupEventId||state._scsClientTournamentId||'';
      return String(parent)===String(masterId)&&String(childId)===eventId&&wanted.has(eventId);
    });
    if(!child?.state)continue;
    const state=JSON.parse(JSON.stringify(child.state));
    state._scsCloudTournamentId=child.id;state._scsEventFormat=event.format||'knockout';
    eventStates.push(state);
    localStorage.setItem('scs_knockout_event_'+eventId,JSON.stringify(state));if(event.format==='group')localStorage.setItem('scs_group_event_'+eventId,JSON.stringify(state));
  }
  localStorage.setItem('scs_knockout_multi_event_v1',JSON.stringify(master));
  localStorage.setItem(_scsTournamentCloudIdKey(club.id,'knockout'),masterRow.id);
  return {...masterRow,state:master,_scsEventStates:eventStates};
}

// Group tournaments use the same master/event ownership model as knockout.
// The master's event list is authoritative, so deleted historical child rows
// cannot silently return when a tournament is opened on another device.
async function dbLoadGroupTournamentFamily(masterId) {
  const club=getMyClub();
  if(!club?.id||!masterId)return null;
  const rows=await sbGet('tournaments',
    `club_id=eq.${encodeURIComponent(club.id)}&format=in.(knockout,group)&order=updated_at.desc&select=id,format,title,status,state_version,created_by,started_at,completed_at,updated_at,state`
  ).catch(()=>[]);
  const masters=rows.filter(row=>row.state?._scsMainTournament&&String(row.state._scsClientTournamentId||row.state.id)===String(masterId));
  const masterRow=masters[0];
  if(!masterRow?.state)return null;
  const master=JSON.parse(JSON.stringify(masterRow.state));
  master._scsCloudTournamentId=masterRow.id;
  const wanted=new Set((Array.isArray(master.events)?master.events:[]).map(event=>String(event.id)));
  const eventStates=[];
  for(const event of (master.events||[])){
    const eventId=String(event.id);
    const child=rows.find(row=>{
      const childState=row.state||{};
      if(childState._scsMainTournament||childState._scsGroupKnockoutStage!=null||row.format!==(event.format||'group'))return false;
      const parent=childState._scsParentTournamentId||'';
      const childId=childState._scsGroupEventId||childState._scsKoEventId||childState._scsClientTournamentId||'';
      return String(parent)===String(masterId)&&String(childId)===eventId&&wanted.has(eventId);
    });
    if(!child?.state)continue;
    const childState=JSON.parse(JSON.stringify(child.state));
    childState._scsCloudTournamentId=child.id;childState._scsEventFormat=event.format||'group';
    eventStates.push(childState);
    localStorage.setItem((event.format==='knockout'?'scs_knockout_event_':'scs_group_event_')+eventId,JSON.stringify(childState));
  }
  localStorage.setItem('scs_group_multi_event_v1',JSON.stringify(master));
  localStorage.setItem(_scsTournamentCloudIdKey(club.id,'group'),masterRow.id);
  return {...masterRow,state:master,_scsEventStates:eventStates};
}

async function dbAdoptTournamentById(id) {
  const row = await dbLoadTournamentById(id);
  if (!row) return null;
  const club = getMyClub();
  if (!club || !club.id) return null;
  const previous = _scsTournamentSaveTimers.get(row.format);
  if (previous) clearTimeout(previous);
  _scsTournamentSaveTimers.delete(row.format);
  row.state._scsCloudTournamentId = row.id;
  _scsTournamentClientId(row.state);
  localStorage.setItem(_scsTournamentCloudIdKey(club.id, row.format), row.id);
  const localKey=row.state._scsMainTournament
    ? (row.format==='group'?'scs_group_multi_event_v1':row.format==='team'?'scs_team_main_tournament_v1':'scs_knockout_multi_event_v1')
    : (row.format === 'team' ? 'scs_team_tournament_v1' : row.format === 'group' ? 'scs_group_tournament_ui_v1' : 'scs_knockout_tournament_v94');
  localStorage.setItem(localKey,JSON.stringify(row.state));
  return row;
}

async function dbDeleteTournamentById(id) {
  const club = getMyClub();
  if (!club || !club.id || !id) return false;
  const found=await sbGet('tournaments',
    `id=eq.${encodeURIComponent(id)}&club_id=eq.${encodeURIComponent(club.id)}&select=id,format,state&limit=1`
  ).catch(()=>[]);
  const row=found?.[0];
  if (!row) throw new Error('Tournament not found or already deleted.');
  const state=row.state||{};
  const clientId=String(state._scsClientTournamentId||'');
  const eventId=String(state._scsKoEventId||state._scsGroupEventId||clientId);
  const parentId=String(state._scsParentTournamentId||state._scsTeamMainId||state._scsKoMainId||'');
  const all=await sbGet('tournaments',
    `club_id=eq.${encodeURIComponent(club.id)}&${row.format==='team'?'format=eq.team':'format=in.(knockout,group)'}&select=id,format,state`
  );
  const targets=all.filter(candidate=>{
    const value=candidate.state||{};
    const candidateClient=String(value._scsClientTournamentId||'');
    const candidateEvent=String(value._scsKoEventId||value._scsGroupEventId||candidateClient);
    const candidateParent=String(value._scsParentTournamentId||value._scsTeamMainId||value._scsKoMainId||'');
    if(state._scsMainTournament){
      return (value._scsMainTournament&&clientId&&candidateClient===clientId)||
        (!value._scsMainTournament&&clientId&&candidateParent===clientId);
    }
    return eventId&&candidateEvent===eventId&&(!parentId||!candidateParent||candidateParent===parentId);
  });
  if(!targets.some(candidate=>String(candidate.id)===String(id)))targets.push(row);
  // Cancel every queued/in-flight identity before deleting so an autosave cannot
  // recreate a row after the user confirmed permanent deletion.
  const activeSaves=[];
  targets.forEach(candidate=>{
    const value=candidate.state||{};
    if(!value._scsClientTournamentId)return;
    const key=_scsTournamentSaveKey(club.id,candidate.format||row.format,value);
    const timer=_scsTournamentSaveTimers.get(key);
    if(timer)clearTimeout(timer);
    _scsTournamentSaveTimers.delete(key);
    _scsTournamentPending.delete(key);
    const chain=_scsTournamentSaveChains.get(key);
    if(chain)activeSaves.push(chain.catch(()=>{}));
    _scsTournamentServerIds.delete(key);
  });
  if(activeSaves.length)await Promise.all(activeSaves);
  targets.forEach(candidate=>{
    const value=candidate.state||{};
    if(value._scsClientTournamentId)_scsTournamentSaveChains.delete(_scsTournamentSaveKey(club.id,candidate.format||row.format,value));
  });
  for(const target of targets){
    await sbDelete('tournaments',`id=eq.${encodeURIComponent(target.id)}&club_id=eq.${encodeURIComponent(club.id)}`);
  }
  const deletedIds=new Set(targets.map(target=>String(target.id)));
  const remaining=await sbGet('tournaments',
    `club_id=eq.${encodeURIComponent(club.id)}&format=eq.${encodeURIComponent(row.format)}&select=id`
  ).catch(()=>[]);
  if(remaining.some(candidate=>deletedIds.has(String(candidate.id))))throw new Error('Server did not permanently delete every saved version.');
  const idKey = _scsTournamentCloudIdKey(club.id, row.format);
  if (deletedIds.has(String(localStorage.getItem(idKey)||''))) {
    localStorage.removeItem(idKey);
    localStorage.removeItem(row.format === 'team' ? 'scs_team_tournament_v1' : row.format === 'group' ? 'scs_group_tournament_ui_v1' : 'scs_knockout_tournament_v94');
  }
  if(row.format==='knockout'){
    if(state._scsMainTournament){
      targets.forEach(target=>{
        const value=target.state||{},id=value._scsKoEventId||(!value._scsMainTournament&&value._scsClientTournamentId)||'';
        if(!id)return;
        localStorage.removeItem('scs_knockout_event_'+id);
        localStorage.removeItem('scs_knockout_assist_draft_v1-'+id);
      });
      localStorage.removeItem('scs_knockout_multi_event_v1');
    }else if(eventId){
      localStorage.removeItem('scs_knockout_event_'+eventId);
      localStorage.removeItem('scs_knockout_assist_draft_v1-'+eventId);
    }
  }
  if(row.format==='group'){
    if(state._scsMainTournament){
      targets.forEach(target=>{
        const value=target.state||{},id=value._scsGroupEventId||(!value._scsMainTournament&&value._scsClientTournamentId)||'';
        if(id)localStorage.removeItem('scs_group_event_'+id);
      });
      localStorage.removeItem('scs_group_multi_event_v1');
    }else if(eventId){
      localStorage.removeItem('scs_group_event_'+eventId);
    }
  }
  return true;
}

async function scsTournamentHydrateCloud() {
  const tasks = [
    ['knockout', 'scs_knockout_tournament_v94'],
    ['group', 'scs_group_tournament_ui_v1'],
    ['team', 'scs_team_tournament_v1']
  ].map(async ([format, key]) => {
    const local = localStorage.getItem(key);
    // A local snapshot must never be uploaded merely because the app opened.
    // It may be older than a live cloud tournament from another device.
    if (local) return false;
    const row = await dbLoadLatestTournament(format);
    if (!row || !row.state) return false;
    row.state._scsCloudTournamentId=row.id;
    _scsTournamentClientId(row.state);
    localStorage.setItem(key, JSON.stringify(row.state));
    return true;
  });
  const restored = await Promise.all(tasks);
  return restored.some(Boolean);
}

window.scsEnsureTournamentClientId = _scsTournamentClientId;
window.dbSaveTournamentState = dbSaveTournamentState;
window.dbLoadLatestTournament = dbLoadLatestTournament;
window.dbListClubTournaments = dbListClubTournaments;
window.dbLoadTournamentById = dbLoadTournamentById;
window.dbLoadKnockoutTournamentFamily = dbLoadKnockoutTournamentFamily;
window.dbAdoptTournamentById = dbAdoptTournamentById;
window.dbDeleteTournamentById = dbDeleteTournamentById;
window.scsQueueTournamentCloudSave = scsQueueTournamentCloudSave;
window.scsResetTournamentCloudIdentity = scsResetTournamentCloudIdentity;
window.scsGetTournamentCloudIdentity = scsGetTournamentCloudIdentity;
window.scsTournamentHydrateCloud = scsTournamentHydrateCloud;


// ─────────────────────────────────────────────────────────────
//  BUILD 1120 — LOCAL-FIRST CLUB SNAPSHOT
//  The selected club is small, so keep a complete on-device copy.
//  Normal UI can paint from local caches; explicit/automatic sync refreshes
//  this snapshot from the server. Individual table failures never discard the
//  last good local club copy.
// ─────────────────────────────────────────────────────────────
async function scsDownloadClubSnapshot(clubId) {
  const id = String(clubId || '');
  if (!id || !window.SCSOfflineDB || typeof SCSOfflineDB.saveClubSnapshot !== 'function') return null;

  const previousRow = await SCSOfflineDB.getClubSnapshot(id).catch(() => null);
  const previous = previousRow && previousRow.data ? previousRow.data : {};
  const snapshot = Object.assign({}, previous, { clubId:id, downloadedAt:new Date().toISOString() });

  async function load(name, table, query) {
    try { snapshot[name] = await sbGet(table, query); }
    catch (error) { console.warn('Local club download skipped ' + name + ':', error && error.message ? error.message : error); }
  }

  await Promise.all([
    load('club', 'clubs', `id=eq.${id}&select=id,name,parent_club_id,created_by,created_at`),
    load('memberships', 'memberships', `club_id=eq.${id}&select=*`),
    load('slots', 'slots', `club_id=eq.${id}&select=*`),
    load('sessions', 'sessions', `club_id=eq.${id}&select=*`),
    load('tournaments', 'tournaments', `club_id=eq.${id}&select=*`),
    load('joinRequests', 'club_join_requests', `club_id=eq.${id}&select=*`),
    load('roles', 'user_club_roles', `club_id=eq.${id}&select=*`)
  ]);

  const playerIds = [...new Set((snapshot.memberships || []).map(r => r && r.player_id).filter(Boolean).map(String))];
  if (playerIds.length) await load('players', 'players', `id=in.(${playerIds.join(',')})&select=*`);

  const slotIds = [...new Set((snapshot.slots || []).map(r => r && r.id).filter(Boolean).map(String))];
  if (slotIds.length) await load('slotClaims', 'slot_claims', `slot_id=in.(${slotIds.join(',')})&select=*`);

  /* active_sessions is the account login-lock table, not a club session table.
     Optional broadcasts/venues and the legacy player_sessions table are not
     part of every deployment's club schema, so the core offline snapshot must
     not query them unconditionally. */
  const sessionIds = [...new Set((snapshot.sessions || []).map(r => r && r.id).filter(Boolean).map(String))];
  if (sessionIds.length) {
    await load('matches', 'matches', `session_id=in.(${sessionIds.join(',')})&select=*`);
  }

  snapshot.syncedAt = Date.now();
  await SCSOfflineDB.saveClubSnapshot(id, snapshot);
  // Keep the normalized IndexedDB mirror in the same row shape as Supabase.
  // Snapshot storage remains for backward compatibility while Practice code
  // moves incrementally to table-oriented local reads.
  if (typeof SCSOfflineDB.saveTableRows === 'function') {
    await Promise.all([
      SCSOfflineDB.saveTableRows('clubs', snapshot.club || []).catch(() => 0),
      SCSOfflineDB.saveTableRows('memberships', snapshot.memberships || []).catch(() => 0),
      SCSOfflineDB.saveTableRows('slots', snapshot.slots || []).catch(() => 0),
      SCSOfflineDB.saveTableRows('sessions', snapshot.sessions || []).catch(() => 0),
      SCSOfflineDB.saveTableRows('players', snapshot.players || []).catch(() => 0),
      SCSOfflineDB.saveTableRows('slot_claims', snapshot.slotClaims || []).catch(() => 0),
      SCSOfflineDB.saveTableRows('matches', snapshot.matches || []).catch(() => 0)
    ]);
  }
  if (Array.isArray(snapshot.slots) && typeof SCSOfflineDB.saveVaultSlotsCache === 'function') {
    await SCSOfflineDB.saveVaultSlotsCache(id, snapshot.slots).catch(() => {});
  }
  localStorage.setItem('scs_local_club_snapshot_at_' + id, String(snapshot.syncedAt));
  window.dispatchEvent(new CustomEvent('scs:club-snapshot-updated', { detail:{ clubId:id, at:snapshot.syncedAt } }));
  return snapshot;
}

async function scsGetLocalClubSnapshot(clubId) {
  const id = String(clubId || '');
  if (!id || !window.SCSOfflineDB || typeof SCSOfflineDB.getClubSnapshot !== 'function') return null;
  const row = await SCSOfflineDB.getClubSnapshot(id).catch(() => null);
  return row && row.data ? row.data : null;
}

window.scsDownloadClubSnapshot = scsDownloadClubSnapshot;
window.scsGetLocalClubSnapshot = scsGetLocalClubSnapshot;

// ─────────────────────────────────────────────────────────────
//  CLUB SESSION — which club is active
// ─────────────────────────────────────────────────────────────

function getMyClub() {
  const id   = localStorage.getItem('kbrr_my_club_id')   || null;
  const name = localStorage.getItem('kbrr_my_club_name') || null;
  return { id, name };
}

function setMyClub(id, name) {
  window.SCSClubSport?.assertKnown(id);
  localStorage.setItem('kbrr_my_club_id',   id);
  localStorage.setItem('kbrr_my_club_name', name);
  if (typeof scsRefreshHomeClubCard === 'function') scsRefreshHomeClubCard();
  if (typeof scsActivityRefreshClub === 'function') scsActivityRefreshClub();
  if (typeof updateWelcomeWorkspaceClubNames === 'function') updateWelcomeWorkspaceClubNames();
  if (typeof homeRefreshTiles        === 'function') homeRefreshTiles();
  if (typeof homeRefreshJoinClubTile === 'function') homeRefreshJoinClubTile();
  if (typeof vaultSyncStatus         === 'function') vaultSyncStatus();
  // Refresh topbar subtitle with new club name
  if (typeof updateModePill === 'function') {
    var mode = localStorage.getItem('kbrr_app_mode') || 'organiser';
    updateModePill(mode);
  }
  // Keep a full local copy for the selected club. This is non-blocking so a
  // club switch never waits for the network.
  if (id && navigator.onLine && typeof scsDownloadClubSnapshot === 'function') {
    setTimeout(function(){ scsDownloadClubSnapshot(id).catch(function(){}); }, 0);
  }
}

function clearMyClub() {
  localStorage.removeItem('kbrr_my_club_id');
  localStorage.removeItem('kbrr_my_club_name');
  if (typeof scsRefreshHomeClubCard === 'function') scsRefreshHomeClubCard();
  if (typeof scsActivityRefreshClub === 'function') scsActivityRefreshClub();
}

// ─────────────────────────────────────────────────────────────
//  PLAYERS API
// ─────────────────────────────────────────────────────────────

async function dbGetPlayers(forceFresh = false) {
  const now       = Date.now();
  const lastFetch = parseInt(localStorage.getItem(CACHE_TIMESTAMP) || '0');
  const cached    = localStorage.getItem(CACHE_PLAYERS);
  const club      = getMyClub();

  const cachedClubId  = localStorage.getItem('kbrr_cache_club_id');
  const currentClubId = club.id ? String(club.id) : 'none';
  if (cachedClubId !== currentClubId) {
    localStorage.removeItem(CACHE_PLAYERS);
    localStorage.removeItem(CACHE_TIMESTAMP);
    localStorage.setItem('kbrr_cache_club_id', currentClubId);
  }

  if (!forceFresh && cached && cachedClubId === currentClubId && (now - lastFetch) < CACHE_TTL_MS) {
    return JSON.parse(cached);
  }

  // Local-first: after the club has been downloaded, use its on-device roster
  // immediately. A manual/automatic sync passes forceFresh=true and refreshes
  // from the server.
  if (!forceFresh && club.id && typeof scsGetLocalClubSnapshot === 'function') {
    try {
      const snap = await scsGetLocalClubSnapshot(club.id);
      if (snap && Array.isArray(snap.memberships) && snap.memberships.length) {
        const byId = new Map((snap.players || []).map(p => [String(p.id), p]));
        const normalized = snap.memberships.map(m => {
          const p = byId.get(String(m.player_id)) || {};
          return {
            id: m.player_id, membershipId:m.id, name:m.nickname,
            gender:p.gender || 'Male', rating:parseFloat(p.global_rating) || 1.0,
            clubRating:parseFloat(m.club_rating) || 1.0,
            activeRating:parseFloat(m.club_rating) || 1.0,
            wins:p.wins || 0, losses:p.losses || 0, sessions:p.sessions || []
          };
        });
        localStorage.setItem(CACHE_PLAYERS, JSON.stringify(normalized));
        localStorage.setItem(CACHE_TIMESTAMP, String(Date.now()));
        return normalized;
      }
    } catch (_) {}
  }

  try {
    let normalized;
    if (club.id) {
      const memberships = await sbGet('memberships',
        `club_id=eq.${club.id}&order=nickname.asc&select=id,nickname,club_rating,club_points,is_playing,player_id,players(id,gender,global_rating,global_points,wins,losses,sessions)`
      );
      normalized = memberships.map(m => ({
        id:           m.player_id,
        membershipId: m.id,
        name:         m.nickname,
        gender:       m.players?.gender            || 'Male',
        rating:       parseFloat(m.players?.global_rating) || 1.0,
        clubRating:   parseFloat(m.club_rating)            || 1.0,
        activeRating: parseFloat(m.club_rating)            || 1.0,
        wins:         m.players?.wins    || 0,
        losses:       m.players?.losses  || 0,
        sessions:     m.players?.sessions || []
      }));
    } else {
      normalized = [];
    }

    localStorage.setItem(CACHE_PLAYERS,   JSON.stringify(normalized));
    localStorage.setItem(CACHE_TIMESTAMP, String(Date.now()));
    return normalized;

  } catch (e) {
    console.warn('Worker offline — using cached players:', e.message);
    return cached ? JSON.parse(cached) : [];
  }
}

function scsNormalizePlayerName(value) {
  var name = String(value == null ? '' : value).normalize('NFKC')
    .replace(/[\p{Cc}\p{Cf}]/gu, '')
    .replace(/\s+/gu, ' ')
    .trim();
  var hasVisibleName = /[\p{L}\p{N}]/u.test(name);
  var allowed = /^[\p{L}\p{M}\p{N} .'’_-]+$/u.test(name);
  return { name:name, valid:!!name && name.length <= 60 && hasVisibleName && allowed };
}

function scsRequireValidPlayerName(value) {
  var result = scsNormalizePlayerName(value);
  if (!result.valid) throw new Error((typeof t === 'function' && t('invalidPlayerName')) || 'Use only letters, numbers, spaces, apostrophes, periods, hyphens or underscores.');
  return result.name;
}

async function dbAddPlayer(name, gender, _unused) {
  const club = getMyClub();
  if (!club.id) throw new Error(t('noClubSelectedJoin'));
  const cleanName = scsRequireValidPlayerName(name);

  const existing = await sbGet('memberships',
    `club_id=eq.${club.id}&nickname=ilike.${encodeURIComponent(cleanName)}&select=id`);
  if (existing.length) throw new Error(t('nicknameExists'));

  const created = await sbPost('players', {
    name:          cleanName,
    gender:        gender,
    global_rating: 1.0,
    global_points: 0
  });
  const player = created[0];

  await sbPost('memberships', {
    player_id:   player.id,
    club_id:     club.id,
    nickname:    cleanName,
    club_rating: 1.0,
    club_points: 0
  });

  localStorage.removeItem(CACHE_PLAYERS);
  localStorage.removeItem(CACHE_TIMESTAMP);
  if (typeof syncToLocal === 'function') await syncToLocal();

  return player;
}

// ─────────────────────────────────────────────────────────────
//  OFFLINE SYNC QUEUE
// ─────────────────────────────────────────────────────────────

const SYNC_QUEUE_KEY = 'kbrr_sync_queue';

function queuePush(updates) {
  try {
    const q = JSON.parse(localStorage.getItem(SYNC_QUEUE_KEY) || '[]');
    updates.forEach(u => q.push({ ...u, timestamp: Date.now() }));
    localStorage.setItem(SYNC_QUEUE_KEY, JSON.stringify(q));
  } catch(e) { console.error('queuePush error', e); }
}

function queueClear() { localStorage.removeItem(SYNC_QUEUE_KEY); }

function queueGet() {
  try { return JSON.parse(localStorage.getItem(SYNC_QUEUE_KEY) || '[]'); }
  catch(e) { return []; }
}

async function flushSyncQueue() {
  const pending = queueGet();
  if (!pending.length) return;
  const club = getMyClub();
  if (!club.id) return;
  const failed = [];
  for (const update of pending) {
    try {
      const rounded = Math.round(update.activeRating * 10) / 10;
      const mrows   = await sbGet('memberships',
        `club_id=eq.${club.id}&nickname=ilike.${encodeURIComponent(update.name)}&select=id,player_id,club_rating,club_points`
      );
      if (!mrows || !mrows.length) continue;
      const m = mrows[0];
      await sbPatch('memberships', `id=eq.${m.id}`, { club_rating: rounded });
      if (update.wins > 0 || update.losses > 0) {
        const prows = await sbGet('players', `id=eq.${m.player_id}&select=wins,losses`);
        if (prows && prows.length) {
          await sbPatch('players', `id=eq.${m.player_id}`, {
            wins:   (prows[0].wins   || 0) + (update.wins   || 0),
            losses: (prows[0].losses || 0) + (update.losses || 0)
          });
        }
      }
    } catch(e) { failed.push(update); }
  }
  if (failed.length) localStorage.setItem(SYNC_QUEUE_KEY, JSON.stringify(failed));
  else queueClear();
}

// ─────────────────────────────────────────────────────────────
//  SYNC RATINGS
// ─────────────────────────────────────────────────────────────

async function dbSyncRatings(updatedRatings) {
  if(window.SCSRoundStorage?.isLocal()) return;
  const club = getMyClub();
  if (!club.id) return;
  const ratingField = localStorage.getItem('kbrr_rating_field') || 'club_rating';
  const failed = [];

  for (const update of updatedRatings) {
    try {
      if (update.guest || update.unrated || /\(guest(?:\s+[a-z0-9]+)?\)$/i.test(String(update.name || ''))) continue;
      const rounded = Math.round(update.activeRating * 10) / 10;
      const mrows   = await sbGet('memberships',
        `club_id=eq.${club.id}&nickname=ilike.${encodeURIComponent(update.name)}&select=id,player_id,club_rating,club_points`
      );
      if (!mrows || !mrows.length) continue;
      const m = mrows[0];
      const prevRating  = parseFloat(m.club_rating) || 1.0;
      const rawDelta    = (update.uncappedDelta !== undefined) ? update.uncappedDelta : (rounded - prevRating);
      const newPoints   = Math.max(0, Math.round(((parseFloat(m.club_points) || 0) + rawDelta) * 10) / 10);
      await sbPatch('memberships', `id=eq.${m.id}`, { club_rating: rounded, club_points: newPoints });

      if (update.wins > 0 || update.losses > 0) {
        const prows = await sbGet('players', `id=eq.${m.player_id}&select=wins,losses,global_points,sessions`);
        if (prows && prows.length) {
          const newGlobalPoints = Math.max(0, Math.round(((parseFloat(prows[0].global_points) || 0) + rawDelta) * 10) / 10);
          const today = localDateStr();
          const existing    = prows[0].sessions || [];
          const otherDays   = existing.filter(s => s.date !== today);
          const todayEntry  = existing.find(s => s.date === today) || {};
          const updatedSession = {
            date:            today,
            wins:            (todayEntry.wins   || 0) + (update.wins   || 0),
            losses:          (todayEntry.losses || 0) + (update.losses || 0),
            points_earned:   Math.max(0, Math.round(((parseFloat(todayEntry.points_earned) || 0) + rawDelta) * 10) / 10),
            club_rating:     rounded,
            cost_per_player: (parseFloat(todayEntry.cost_per_player) || 0) +
              (typeof shuttleData !== 'undefined' && shuttleData ? (parseFloat(shuttleData.cost_per_player) || 0) : 0) || null
          };
          await sbPatch('players', `id=eq.${m.player_id}`, {
            wins:          (prows[0].wins   || 0) + (update.wins   || 0),
            losses:        (prows[0].losses || 0) + (update.losses || 0),
            global_points: newGlobalPoints,
            sessions:      [updatedSession, ...otherDays].slice(0, 30)
          });
        }
      }
    } catch(e) {
      console.warn('dbSyncRatings offline for', update.name, '— queued');
      failed.push(update);
    }
  }
  if (failed.length) queuePush(failed);
  localStorage.removeItem(CACHE_PLAYERS);
  localStorage.removeItem(CACHE_TIMESTAMP);
}

async function dbOverrideRating(playerId, newRating) {
  const club    = getMyClub();
  const rounded = Math.round(newRating * 10) / 10;
  if (club.id) {
    await sbPatch('memberships', `player_id=eq.${playerId}&club_id=eq.${club.id}`, { club_rating: rounded });
  }
  localStorage.removeItem(CACHE_PLAYERS);
  localStorage.removeItem(CACHE_TIMESTAMP);
  if (typeof syncToLocal === 'function') await syncToLocal();
}

async function dbEditPlayer(playerId, updates, clubAdminPassword) {
  const club = getMyClub();
  if (!club.id) throw new Error(t('noClubSelectedJoin'));
  const verified = await dbVerifyClubPassword(club.id, clubAdminPassword, 'admin');
  if (!verified.valid) throw new Error(t('wrongAdminPassword'));
  const { nickname, club_rating, ...playerUpdates } = updates;
  if (nickname || club_rating) {
    const mPatch = {};
    if (nickname)              mPatch.nickname    = nickname;
    if (club_rating !== undefined) mPatch.club_rating = club_rating;
    await sbPatch('memberships', `player_id=eq.${playerId}&club_id=eq.${club.id}`, mPatch);
  }
  if (Object.keys(playerUpdates).length) {
    await sbPatch('players', `id=eq.${playerId}`, playerUpdates);
  }
  localStorage.removeItem(CACHE_PLAYERS);
  localStorage.removeItem(CACHE_TIMESTAMP);
}

async function dbDeletePlayer(playerId, clubAdminPassword) {
  const club = getMyClub();
  if (!club.id) throw new Error(t('noClubSelectedJoin'));
  const verified = await dbVerifyClubPassword(club.id, clubAdminPassword, 'admin');
  if (!verified.valid) throw new Error(t('wrongAdminPassword'));
  const memberships = await sbGet('memberships',
    `player_id=eq.${playerId}&club_id=eq.${club.id}&select=user_account_id`);
  const accountIds = Array.from(new Set((memberships || []).map(function(row) {
    return String(row.user_account_id || '');
  }).filter(Boolean)));
  await sbDelete('memberships', `player_id=eq.${playerId}&club_id=eq.${club.id}`);
  for (const accountId of accountIds) {
    await sbDelete('user_club_roles',
      `club_id=eq.${club.id}&user_account_id=eq.${encodeURIComponent(accountId)}`).catch(function() {});
    await sbDelete('club_join_requests',
      `club_id=eq.${club.id}&user_account_id=eq.${encodeURIComponent(accountId)}`).catch(function() {});
  }
  localStorage.removeItem(CACHE_PLAYERS);
  localStorage.removeItem(CACHE_TIMESTAMP);
  if (typeof syncToLocal === 'function') await syncToLocal();
}

// ─────────────────────────────────────────────────────────────
//  CLUBS API
// ─────────────────────────────────────────────────────────────

async function dbGetClubs() {
  try { return await sbGet('clubs', 'select=id,name,sport&order=name.asc'); }
  catch(e) { return []; }
}

async function dbAddClub(clubName, selectPassword, adminPassword, registrationEmail) {
  const sport = window.SCSClubSport?.current() || (document.documentElement.dataset.scsSport === 'pickleball' ? 'pickleball' : 'badminton');
  if (!clubName.trim())  throw new Error(t('enterClubName'));
  if (!adminPassword)    throw new Error(t('enterAdminPw'));
  // The legacy member-password column remains populated for schema
  // compatibility, but Organiser access is granted by club membership.
  if (!selectPassword) {
    selectPassword = 'membership-only-' + (globalThis.crypto && crypto.randomUUID
      ? crypto.randomUUID()
      : (Date.now().toString(36) + Math.random().toString(36).slice(2)));
  }

  // Limit: one club per account — uses created_by (uuid) which already exists in schema
  const SUPER_ADMIN_EMAIL = 'karikalan.iphone@gmail.com';
  var user = (typeof authGetUser === 'function') ? authGetUser() : null;
  if (user && user.id && user.email && user.email.trim().toLowerCase() !== SUPER_ADMIN_EMAIL) {
    var existing = await sbGet('clubs', 'created_by=eq.' + user.id + '&sport=eq.' + sport + '&select=id');
    if (existing && existing.length >= 1) {
      throw new Error('You have already created a club for this sport. One club per sport is allowed per account.');
    }
  }

  const payload = { name: clubName.trim(), sport, select_password: selectPassword, admin_password: adminPassword };
  // Always store creator's user id in created_by
  if (user && user.id) payload.created_by = user.id;
  const created = await sbPost('clubs', payload);
  const club = created[0];

  // The creator must immediately be a member of the club they created.
  // Club selectors and the Slot Manager are membership-driven, so creating
  // only the clubs row leaves the new club invisible to its owner.
  if (club && club.id && user && user.id) {
    var creatorPlayerId = null;
    try {
      var accountRows = await sbGet('user_accounts',
        'id=eq.' + encodeURIComponent(user.id) + '&select=nickname,email,gender');
      var account = accountRows && accountRows[0] ? accountRows[0] : {};
      var creatorNickname = String(
        account.nickname || user.nickname || user.display_name ||
        account.email || user.email || 'Club Owner'
      ).trim();
      if (creatorNickname.indexOf('@') > 0) creatorNickname = creatorNickname.split('@')[0];
      var creatorGender = (account.gender === 'Female' || user.gender === 'Female') ? 'Female' : 'Male';

      // Idempotent guard in case a retry happens after a slow network response.
      var existingMembership = await sbGet('memberships',
        'club_id=eq.' + encodeURIComponent(club.id) +
        '&user_account_id=eq.' + encodeURIComponent(user.id) + '&select=id');

      if (!existingMembership || !existingMembership.length) {
        var playerRows = await sbPost('players', {
          name: creatorNickname,
          gender: creatorGender,
          global_rating: 1.0,
          global_points: 0,
          user_account_id: user.id
        });
        creatorPlayerId = playerRows && playerRows[0] ? playerRows[0].id : null;
        if (!creatorPlayerId) throw new Error('Could not create the owner player record.');

        await sbPost('memberships', {
          player_id: creatorPlayerId,
          club_id: club.id,
          nickname: creatorNickname,
          club_rating: 1.0,
          club_points: 0,
          user_account_id: user.id
        });
      }
    } catch (membershipError) {
      // Do not leave a half-created club that the owner cannot access.
      if (creatorPlayerId) await sbDelete('players', 'id=eq.' + encodeURIComponent(creatorPlayerId)).catch(function(){});
      await sbDelete('clubs', 'id=eq.' + encodeURIComponent(club.id)).catch(function(){});
      throw new Error('Club could not be linked to your player account: ' + (membershipError.message || membershipError));
    }
  }

  localStorage.removeItem(CACHE_PLAYERS);
  localStorage.removeItem(CACHE_TIMESTAMP);
  return club;
}

async function scsResolveOrganizerClub(){
 const current=getMyClub();
 if(!current?.id)throw new Error('Select a main club first.');
 const rows=await sbGet('clubs','id=eq.'+encodeURIComponent(current.id)+'&select=id,name,parent_club_id');
 const active=rows?.[0];
 if(!active)throw new Error('Club not found.');
 if(!active.parent_club_id)return {id:active.id,name:active.name};
 const parents=await sbGet('clubs','id=eq.'+encodeURIComponent(active.parent_club_id)+'&select=id,name,parent_club_id');
 if(!parents?.[0]||parents[0].parent_club_id)throw new Error('Main club not found.');
 return {id:parents[0].id,name:parents[0].name};
}
// Sub-clubs reuse the existing clubs and memberships tables.
async function dbGetSubClubs(parentId) {
  if (!parentId) return [];
  return sbGet('clubs', 'parent_club_id=eq.' + encodeURIComponent(parentId) + '&select=id,name,parent_club_id,sport&order=name.asc');
}
async function dbAddSubClub(parentId, name, adminPassword) {
  const clean = String(name || '').trim();
  if (!parentId || !clean) throw new Error('Select a main club and enter a sub-club name.');
  if (!adminPassword) throw new Error('Main club administrator password required.');
  const parents = await sbGet('clubs','id=eq.' + encodeURIComponent(parentId) + '&select=id,name,parent_club_id,created_by,sport');
  const parent = parents && parents[0];
  if (!parent || parent.parent_club_id) throw new Error('Sub-clubs can only be created under a main club.');
  if (!['badminton','pickleball'].includes(parent.sport)) throw new Error('The main club owner must assign its sport in My Clubs first.');
  // Reuse the existing club administration password verification, rather than
  // relying on Practice-only kbrr_club_mode or the original creator's user ID.
  const verified = await dbVerifyClubPassword(parentId, adminPassword, 'admin');
  if (!verified.valid) throw new Error('Incorrect main club administrator password.');
  const existing = await dbGetSubClubs(parentId);
  if (existing.some(c => c.name.trim().toLowerCase() === clean.toLowerCase())) throw new Error('Sub-club already exists.');
  const token = 'membership-only-' + (globalThis.crypto && crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36));
  const payload = {name:clean,parent_club_id:parentId,sport:parent.sport,select_password:token,admin_password:token};
  if (parent.created_by) payload.created_by=parent.created_by;
  const rows = await sbPost('clubs',payload);
  const child = rows && rows[0];
  if (!child || !child.id) throw new Error('Sub-club creation failed.');
  return child;
}

// ─────────────────────────────────────────────────────────────
//  AUTH — OTP via Worker (keys never leave server)
// ─────────────────────────────────────────────────────────────

async function dbSendOtp(email) {
  const res = await fetch(WORKER_URL + '/auth/supabase-otp', {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ email: email.trim().toLowerCase() })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to send OTP');
  }
  return true;
}

async function dbVerifyOtp(email, token) {
  const res = await fetch(WORKER_URL + '/auth/supabase-verify', {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ email: email.trim().toLowerCase(), token: token.trim() })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Invalid or expired OTP');
  }
  if (typeof onUserLogin === 'function') await onUserLogin(email.trim().toLowerCase());
  return true;
}

async function dbGetClubRegEmail(clubId) {
  const rows = await sbGet('clubs', `id=eq.${clubId}&select=registration_email`);
  if (!rows || !rows.length) throw new Error(t('clubNotFound'));
  return rows[0].registration_email || null;
}

function maskEmail(email) {
  if (!email) return '';
  const [user, domain] = email.split('@');
  const masked = user[0] + '***' + (user.length > 1 ? user.slice(-1) : '');
  return masked + '@' + domain;
}

async function dbVerifyClubPassword(clubId, password, kind = 'select') {
  const column = kind === 'admin' ? 'admin_password' : 'select_password';
  const rows = await sbGet('clubs', 'id=eq.' + encodeURIComponent(clubId) + '&' + column + '=eq.' + encodeURIComponent(password) + '&select=id,name');
  return { valid:!!(rows && rows.length), club:rows && rows[0] || null };
}
window.dbVerifyClubPassword = dbVerifyClubPassword;

async function dbVerifyClubAccess(clubId, selectPassword) {
  const result = await dbVerifyClubPassword(clubId, selectPassword, 'select');
  if (!result || !result.valid) throw new Error(t('wrongPasswordHint'));
  return result.club;
}

// ─────────────────────────────────────────────────────────────
//  SYNC AFTER ROUND
// ─────────────────────────────────────────────────────────────

async function syncAfterRound(roundWins, roundLosses, roundRatingDeltas) {
  if(window.SCSRoundStorage?.isLocal()) return;
  try {
    const playedNames    = new Set([...roundWins.keys(), ...roundLosses.keys()]);
    const updatedRatings = schedulerState.allPlayers
      .filter(p => playedNames.has(p.name))
      .filter(p => !(p.guest || p.unrated || /\(guest(?:\s+[a-z0-9]+)?\)$/i.test(String(p.name || ''))))
      .map(p => ({
        name:          p.name,
        activeRating:  getActiveRating(p.name),
        uncappedDelta: (roundRatingDeltas && roundRatingDeltas.get(p.name)) || 0,
        wins:          (roundWins   && roundWins.get(p.name))   || 0,
        losses:        (roundLosses && roundLosses.get(p.name)) || 0
      }));
    await dbSyncRatings(updatedRatings);
    await dbRecordRoundMatches(updatedRatings);
    await syncLiveSession(playedNames);
    await syncToLocal();
  } catch(e) { console.error('syncAfterRound error:', e.message); }
}

async function syncSessionAfterRound(playedNames) {}

// Round iMode keeps play local and performs one server sync when End is used.
// At End, create the same linked Slot used by normal Round Mode so the
// completed iMode session appears in the existing player-payment flow.
// The persisted iModeSyncTotals object survives app closure through snapshot.js.
async function syncRoundIModeSession(shuttleData = null) {
  if(window.SCSRoundStorage?.isLocal()) return true;
  try {
    if (!navigator.onLine || !(await dbIsOnline())) return false;
    let sessionId = getMySessionId();
    if (!sessionId) {
      let paymentSlot = null;
      if (typeof vaultSlotsCreatePostedFromRoundManager === 'function') {
        try {
          paymentSlot = await vaultSlotsCreatePostedFromRoundManager();
        } catch (slotError) {
          console.warn('Round iMode payment slot post failed:', slotError && slotError.message ? slotError.message : slotError);
        }
      }
      sessionId = await dbStartSession(paymentSlot && paymentSlot.id ? paymentSlot.id : null);
    }
    if (!sessionId) return false;

    const totals = (typeof schedulerState !== 'undefined' && schedulerState.iModeSyncTotals) || {};
    const players = (typeof schedulerState !== 'undefined' && schedulerState.allPlayers) || [];
    const updates = players
      .filter(player => player && !player.guest && !player.unrated)
      .map(player => {
        const total = totals[player.name] || { wins:0, losses:0, delta:0 };
        return {
          name: player.name,
          activeRating: typeof getActiveRating === 'function' ? getActiveRating(player.name) : (Number(player.rating) || 1),
          uncappedDelta: Number(total.delta) || 0,
          wins: Number(total.wins) || 0,
          losses: Number(total.losses) || 0
        };
      });

    await dbSyncRatings(updates);
    await dbSyncRoundsData();
    await dbCompleteSession(shuttleData);

    // iMode creates its payment Slot only at End, unlike normal Round Mode
    // which creates the Slot when play starts. Any My Hub / Slot Manager slot
    // cache opened before End therefore does not yet contain this new played
    // Slot. Force both existing slot views to reload immediately after the
    // completed session is linked so the payment appears without an app reload.
    if (typeof myCardSlotsScheduleRefresh === 'function') {
      myCardSlotsScheduleRefresh(true);
    } else if (typeof myCardSlotsRefreshAll === 'function') {
      setTimeout(function(){ myCardSlotsRefreshAll(true); }, 0);
    }
    if (typeof renderVaultHomeSlotsUI === 'function') {
      setTimeout(function(){ renderVaultHomeSlotsUI(true); }, 0);
    }

    if (typeof syncToLocal === 'function') await syncToLocal();
    return !getMySessionId();
  } catch (error) {
    console.warn('Round iMode final sync failed:', error && error.message ? error.message : error);
    return false;
  }
}

// ─────────────────────────────────────────────────────────────
//  LIVE SESSIONS
// ─────────────────────────────────────────────────────────────

async function syncLiveSession(playedNames) {
  if(window.SCSRoundStorage?.isLocal()) return;
  try {
    const club = getMyClub();
    if (!club.id) return;
    const today     = localDateStr();
    const players   = schedulerState.allPlayers || [];
    const genderMap = new Map();
    players.forEach(p => genderMap.set(p.name, p.gender || 'Male'));
    const playerMatches = new Map();
    for (const round of (allRounds || [])) {
      const games = round.games || round;
      for (const game of (games || [])) {
        if (!game.winner) continue;
        const leftWon = game.winner === 'L';
        const pair1   = game.pair1 || [], pair2 = game.pair2 || [];
        for (const p of pair1) {
          if (!playerMatches.has(p)) playerMatches.set(p, []);
          playerMatches.get(p).push({
            partner:         pair1.filter(x => x !== p),
            partnerGenders:  pair1.filter(x => x !== p).map(n => genderMap.get(n) || 'Male'),
            opponents:       pair2,
            opponentGenders: pair2.map(n => genderMap.get(n) || 'Male'),
            result:          leftWon ? 'W' : 'L'
          });
        }
        for (const p of pair2) {
          if (!playerMatches.has(p)) playerMatches.set(p, []);
          playerMatches.get(p).push({
            partner:         pair2.filter(x => x !== p),
            partnerGenders:  pair2.filter(x => x !== p).map(n => genderMap.get(n) || 'Male'),
            opponents:       pair1,
            opponentGenders: pair1.map(n => genderMap.get(n) || 'Male'),
            result:          leftWon ? 'L' : 'W'
          });
        }
      }
    }
    const myPlayer  = (typeof getMyPlayer === 'function') ? getMyPlayer() : null;
    const startedBy = myPlayer ? myPlayer.name : null;
    const upserts   = players
      .filter(p => playedNames.has(p.name) && (playerMatches.get(p.name) || []).length)
      .map(() => Promise.resolve());
    await Promise.all(upserts);
  } catch(e) { console.warn('syncLiveSession error:', e.message); }
}

// ─────────────────────────────────────────────────────────────
//  SESSIONS TABLE
// ─────────────────────────────────────────────────────────────

function getMySessionId() { return sessionStorage.getItem('kbrr_session_db_id') || null; }
function setMySessionId(id) {
  if (id) sessionStorage.setItem('kbrr_session_db_id', id);
  else    sessionStorage.removeItem('kbrr_session_db_id');
  if (typeof persistSessionId === 'function') persistSessionId(id);
}

async function dbStartSession(sourceSlotId = null) {
  if(window.SCSRoundStorage?.isLocal()) return null;
  try {
    const club      = getMyClub();
    if (!club.id) return;
    const myPlayer  = (typeof getMyPlayer === 'function') ? getMyPlayer() : null;
    const startedBy = myPlayer ? myPlayer.name : null;
    const today     = localDateStr();
    const payload = {
      club_id:     club.id, date: today, started_by: startedBy,
      status:      'live',  rounds_data: [], players: [],
      updated_at:  new Date().toISOString()
    };
    if (sourceSlotId) payload.source_slot_id = sourceSlotId;

    let created = null;
    try {
      created = await sbPost('sessions', payload);
    } catch (e) {
      if (!sourceSlotId) throw e;
      delete payload.source_slot_id;
      created = await sbPost('sessions', payload);
    }

    const sessionId = created && created[0] ? created[0].id : null;
    setMySessionId(sessionId);
    if (sourceSlotId && sessionId && typeof dbMarkSlotSession === 'function') {
      await dbMarkSlotSession(sourceSlotId, sessionId);
    }
    return sessionId;
  } catch(e) { console.warn('dbStartSession error:', e.message); }
}

async function dbMarkSlotSession(slotId, sessionId) {
  if (!slotId || !sessionId) return false;
  try {
    await sbPatch('slots', `id=eq.${slotId}`, {
      status: 'played',
      played_session_id: sessionId
    });
    return true;
  } catch (e) {
    try {
      await sbPatch('slots', `id=eq.${slotId}`, { status: 'played' });
      return true;
    } catch (e2) {
      console.warn('dbMarkSlotSession error:', e2.message);
      return false;
    }
  }
}

async function dbSyncRoundsData() {
  if(window.SCSRoundStorage?.isLocal()) return;
  try {
    const sessionDbId = getMySessionId();
    if (!sessionDbId) return;
    const roundsData = (allRounds || []).map(r => ({
      round: r.round, resting: r.resting || [],
      winnerEnabled: (typeof getPlayMode === 'function') ? getPlayMode() === 'competitive' : false,
      games: (r.games || []).map(g => ({
        pair1: g.pair1, pair2: g.pair2, winner: g.winner || null, court: g.court || null,
        score: g.score || null, score_status: g.score_status || null,
        winnerEnabled: (typeof getPlayMode === 'function') ? getPlayMode() === 'competitive' : false
      }))
    }));
    // Also persist full scheduler state so any organiser can resume
    const schedulerBlob = (typeof buildSchedulerBlob === 'function') ? buildSchedulerBlob() : null;
    const patch = { rounds_data: roundsData, updated_at: new Date().toISOString() };
    if (schedulerBlob) patch.scheduler_state = schedulerBlob;

    // Keep players list current so report works on live and completed sessions
    if (typeof schedulerState !== 'undefined' && schedulerState.allPlayers && schedulerState.allPlayers.length) {
      const _baseName = n => (n || '').replace(/#\d+$/, '').trim();
      patch.players = schedulerState.allPlayers.map(p => ({
        name:   _baseName(p.name),  // strip #1/#2 suffix to match membership nickname
        wins:   schedulerState.winCount ? (schedulerState.winCount.get(p.name) || 0) : 0,
        losses: schedulerState.PlayedCount
          ? Math.max(0, (schedulerState.PlayedCount.get(p.name) || 0) - (schedulerState.winCount ? (schedulerState.winCount.get(p.name) || 0) : 0))
          : 0
      }));
    }

    await sbPatch('sessions', `id=eq.${sessionDbId}`, patch);
  } catch(e) { console.warn('dbSyncRoundsData error:', e.message); }
}

async function dbCompleteSession(shuttleData = null) {
  if(window.SCSRoundStorage?.isLocal()) return true;
  try {
    const sessionDbId = getMySessionId();
    const club        = getMyClub();
    if (!sessionDbId || !club.id) return;
    const _base = n => (n||'').replace(/#\d+$/, '').trim();
    const players = (schedulerState.allPlayers || []).map(p => ({
      name:   _base(p.name),
      wins:   schedulerState.winCount ? (schedulerState.winCount.get(p.name) || 0) : 0,
      losses: schedulerState.PlayedCount
        ? Math.max(0, (schedulerState.PlayedCount.get(p.name) || 0) - (schedulerState.winCount ? (schedulerState.winCount.get(p.name) || 0) : 0))
        : 0
    }));
    // Keep session forever for monthly/yearly reporting.
    // Purge scheduler_state (large resume blob) immediately — no longer needed.
    // rounds_data kept for win/loss reporting.
    const patch = { status: 'completed', players, updated_at: new Date().toISOString() };
    if (shuttleData) patch.shuttle_data = shuttleData;
    await sbPatch('sessions', `id=eq.${sessionDbId}`, patch);
    const today = localDateStr();
    for (const p of players) {
      if (!p.name) continue;
      try {
        const mrows = await sbGet('memberships',
          `club_id=eq.${club.id}&nickname=ilike.${encodeURIComponent(p.name)}&select=player_id,club_rating,club_points`
        ).catch(() => []);
        if (!mrows.length) continue;
        const playerId = mrows[0].player_id;
        const prows    = await sbGet('players', `id=eq.${playerId}&select=sessions`).catch(() => []);
        const existing = (prows.length ? prows[0].sessions : null) || [];
        const entry = {
          date:            today, session_id: sessionDbId,
          wins:            p.wins || 0, losses: p.losses || 0,
          points_earned:   parseFloat(mrows[0].club_points) || 0,
          club_rating:     parseFloat(mrows[0].club_rating) || 1.0,
          cost_per_player: shuttleData ? (parseFloat(shuttleData.cost_per_player) || 0) : null
        };
        await sbPatch('players', `id=eq.${playerId}`, { sessions: [entry, ...existing].slice(0, 60) }).catch(() => {});
      } catch(e) {}
    }
    setMySessionId(null);
  } catch(e) { console.warn('dbCompleteSession error:', e.message); }
}

async function dbCleanupStaleSessions() {
  try {
    const club = getMyClub();
    if (!club.id) return;
    const rows = await sbGet('sessions', `club_id=eq.${club.id}&status=eq.live&select=id,created_at,updated_at`);
    if (!rows || !rows.length) return;
    const threeHoursAgo = Date.now() - (3 * 60 * 60 * 1000); // 3 hours — genuinely abandoned
    for (const sess of rows) {
      const age = new Date(sess.updated_at || sess.created_at).getTime();
      if (age < threeHoursAgo) {
        await sbPatch('sessions', `id=eq.${sess.id}`, { status: 'completed', updated_at: new Date().toISOString() }).catch(() => {});
        await sbPatch('memberships', `club_id=eq.${club.id}&is_playing=eq.true`, { is_playing: false }).catch(() => {});
      }
    }
  } catch(e) {}
}

async function dbForceCompleteSession(sessionId) {
  try {
    // Purge scheduler_state on completion — keep rounds_data for reporting
    await sbPatch('sessions', `id=eq.${sessionId}`, { status: 'completed', updated_at: new Date().toISOString() });
    const club = getMyClub();
    if (club.id) {
      await sbPatch('memberships', `club_id=eq.${club.id}&is_playing=eq.true`, { is_playing: false }).catch(() => {});
      // sessions kept for monthly reporting — no auto-deletion
    }
  } catch(e) { console.warn('dbForceCompleteSession error:', e.message); }
}

async function dbGetMyJoinedClubIds() {
  try {
    const user = (typeof authGetUser === 'function') ? authGetUser() : null;
    if (user && user.id) {
      const rows = await sbGet('memberships', `user_account_id=eq.${user.id}&select=club_id`);
      return [...new Set((rows || []).map(r => r.club_id).filter(Boolean))];
    }
    return [];
  } catch(e) { return []; }
}

async function dbGetPlayerClubs(playerNameOrId) {
  try {
    const accountClubIds = await dbGetMyJoinedClubIds();
    if (accountClubIds.length) return accountClubIds;

    if (!playerNameOrId) return [];
    const myPlayer = (typeof getMyPlayer === 'function') ? getMyPlayer() : null;
    if (myPlayer && myPlayer.id) {
      const rows = await sbGet('memberships', `player_id=eq.${myPlayer.id}&select=club_id`);
      if (rows && rows.length) return [...new Set(rows.map(r => r.club_id).filter(Boolean))];
    }
    const rows = await sbGet('memberships', `nickname=ilike.${encodeURIComponent(playerNameOrId)}&select=club_id`);
    return [...new Set((rows || []).map(r => r.club_id).filter(Boolean))];
  } catch(e) { return []; }
}

async function dbGetLiveSessions(options = {}) {
  try {
    if(options.strict && navigator.onLine === false)throw new Error('Connect to the internet to refresh matches.');
    if(window.SCSSportContext?.appModule==='scoreboard'){
      const club=getMyClub();if(!club?.id)return [];
      return await sbGet('sessions','club_id=eq.'+encodeURIComponent(club.id)+''+(options.excludeTournaments?'&status=eq.live&started_by=neq.__SCS_TOURNAMENT_COURT_CENTER__':'&or=(status.eq.live,and(status.eq.completed,started_by.eq.__SCS_TOURNAMENT_COURT_CENTER__))')+'&order=created_at.asc&select=id,status,rounds_data,started_by,updated_at,club_id,handover_pin')||[];
    }
    const isViewer = (typeof appMode !== 'undefined') && appMode === 'viewer';
    if (isViewer) {
      const myPlayer = (typeof getMyPlayer === 'function') ? getMyPlayer() : null;
      // Account memberships can identify clubs before a player profile loads.
      const clubIds = await dbGetPlayerClubs(myPlayer && myPlayer.name);
      if (!clubIds.length) return [];
      return await sbGet('sessions', `club_id=in.(${clubIds.join(',')})&status=eq.live${options.excludeTournaments?'&started_by=neq.__SCS_TOURNAMENT_COURT_CENTER__':''}&order=created_at.asc&select=id,rounds_data,started_by,updated_at,club_id,handover_pin`) || [];
    } else {
      const club = getMyClub();
      if (!club.id) return [];
      return await sbGet('sessions', `club_id=eq.${club.id}&status=eq.live${options.excludeTournaments?'&started_by=neq.__SCS_TOURNAMENT_COURT_CENTER__':''}&order=created_at.asc&select=id,rounds_data,started_by,updated_at,handover_pin`) || [];
    }
  } catch(e) { console.warn('dbGetLiveSessions error:', e.message); if(options.strict)throw e; return []; }
}

async function dbGetPastSessions() {
  try {
    const isViewer = (typeof appMode !== 'undefined') && appMode === 'viewer';
    if (isViewer) {
      const myPlayer = (typeof getMyPlayer === 'function') ? getMyPlayer() : null;
      if (!myPlayer) return [];
      const clubIds = await dbGetPlayerClubs(myPlayer.name);
      if (!clubIds.length) return [];
      return await sbGet('sessions', `club_id=in.(${clubIds.join(',')})&status=eq.completed&order=updated_at.desc&limit=5&select=id,date,started_by,players,rounds_data,updated_at,club_id,shuttle_data`) || [];
    } else {
      const club = getMyClub();
      if (!club.id) return [];
      return await sbGet('sessions', `club_id=eq.${club.id}&status=eq.completed&order=updated_at.desc&limit=10&select=id,date,started_by,players,rounds_data,updated_at,shuttle_data`) || [];
    }
  } catch(e) { return []; }
}

// ── Date-range query for calendar coverage — NOT capped by row count ──
// year: 4-digit year, month: 0-indexed (matches JS Date.getMonth())
// Returns every completed session whose date falls within the given month,
// so the dashboard calendar can mark a dot on EVERY day that has a session,
// not just the most recent N.
async function dbGetSessionsForMonth(year, month) {
  try {
    const isViewer = (typeof appMode !== 'undefined') && appMode === 'viewer';
    const pad = n => String(n).padStart(2, '0');
    const startDate = `${year}-${pad(month + 1)}-01`;
    const nextMonth = month === 11 ? 0 : month + 1;
    const nextYear  = month === 11 ? year + 1 : year;
    const endDate   = `${nextYear}-${pad(nextMonth + 1)}-01`; // exclusive upper bound

    if (isViewer) {
      const myPlayer = (typeof getMyPlayer === 'function') ? getMyPlayer() : null;
      if (!myPlayer) return [];
      const clubIds = await dbGetPlayerClubs(myPlayer.name);
      if (!clubIds.length) return [];
      const q = `club_id=in.(${clubIds.join(',')})&status=eq.completed&date=gte.${startDate}&date=lt.${endDate}` +
        `&order=date.asc&select=id,date,started_by,players,rounds_data,updated_at,club_id,shuttle_data,source_slot_id`;
      return await sbGet('sessions', q).catch(() => sbGet('sessions',
        `club_id=in.(${clubIds.join(',')})&status=eq.completed&date=gte.${startDate}&date=lt.${endDate}` +
        `&order=date.asc&select=id,date,started_by,players,rounds_data,updated_at,club_id,shuttle_data`)) || [];
    } else {
      const club = getMyClub();
      if (!club.id) return [];
      const q = `club_id=eq.${club.id}&status=eq.completed&date=gte.${startDate}&date=lt.${endDate}` +
        `&order=date.asc&select=id,date,started_by,players,rounds_data,updated_at,shuttle_data,source_slot_id`;
      return await sbGet('sessions', q).catch(() => sbGet('sessions',
        `club_id=eq.${club.id}&status=eq.completed&date=gte.${startDate}&date=lt.${endDate}` +
        `&order=date.asc&select=id,date,started_by,players,rounds_data,updated_at,shuttle_data`)) || [];
    }
  } catch(e) { console.warn('dbGetSessionsForMonth error:', e.message); return []; }
}

async function dbUpdateLiveMatchScore(sessionId, roundNumber, courtNumber, pair1, pair2, scoreData, winnerSide, ccid) {
  if (!sessionId) return false;
  try {
    const rows = await sbGet('sessions', `id=eq.${encodeURIComponent(sessionId)}&select=id,status,rounds_data`);
    if (!rows || !rows.length) { console.warn('dbUpdateLiveMatchScore: session not found', sessionId); return false; }
    const rounds = Array.isArray(rows[0].rounds_data) ? rows[0].rounds_data : [];
    const samePair = (a,b) => JSON.stringify(a || []) === JSON.stringify(b || []);
    const round = (ccid ? rounds.find(r => (r.games || []).some(g => String(g.ccid || '') === String(ccid))) : null) ||
      rounds.find(r => Number(r.round) === Number(roundNumber));
    if (!round) { console.warn('dbUpdateLiveMatchScore: round not found', { sessionId, roundNumber, ccid }); return false; }
    const games = round.games || [];
    const game = (ccid ? games.find(g => String(g.ccid || '') === String(ccid)) : null) ||
      games.find(g => Number(g.court || 0) === Number(courtNumber || 0) && samePair(g.pair1,pair1) && samePair(g.pair2,pair2));
    if (!game) { console.warn('dbUpdateLiveMatchScore: match not found', { sessionId, roundNumber, courtNumber, ccid, pair1, pair2 }); return false; }
    if(game.court_center_status==='approved')return false;
    game.score = scoreData || null;
    game.score_status = winnerSide ? 'scored' : 'scoring';
    if (winnerSide) game.winner = winnerSide;
    await sbPatch('sessions', `id=eq.${encodeURIComponent(sessionId)}`, { rounds_data: rounds, updated_at: new Date().toISOString() },undefined,round.tournament?{tournamentId:round.tournament._scsCloudTournamentId,matchKey:String(game.tournament_match)}:undefined);
    return true;
  } catch(e) { console.warn('dbUpdateLiveMatchScore error:', e.message); return false; }
}

async function dbFinishTournamentConductMatch(sessionId, ccid) {
  if (!sessionId || !ccid) return false;
  try {
    const rows = await sbGet('sessions', `id=eq.${encodeURIComponent(sessionId)}&status=eq.live&select=id,rounds_data`);
    if (!rows || !rows[0]) return false;
    const rounds = Array.isArray(rows[0].rounds_data) ? rows[0].rounds_data : [];
    let found = false;
    rounds.forEach(round => (round.games || []).forEach(game => {
      if (game.ccid === ccid && game.score_status === 'scored') {
        game.conduct_finished = true;
        game.conduct_finished_at = new Date().toISOString();
        found = true;
      }
    }));
    if (!found) return false;
    await sbPatch('sessions', `id=eq.${encodeURIComponent(sessionId)}`, { rounds_data: rounds, updated_at: new Date().toISOString() });
    return true;
  } catch(e) { console.warn('dbFinishTournamentConductMatch error:', e.message); return false; }
}

window.dbFinishTournamentConductMatch = dbFinishTournamentConductMatch;

async function dbPullExternalLiveScores() {
  if(window.SCSRoundStorage?.isLocal()) return false;
  const sessionId = (typeof getMySessionId === 'function') ? getMySessionId() : null;
  if (!sessionId || typeof allRounds === 'undefined' || !Array.isArray(allRounds)) return false;
  try {
    const rows = await sbGet('sessions', `id=eq.${sessionId}&status=eq.live&select=rounds_data`);
    if (!rows || !rows.length) return false;
    let changed = false;
    (rows[0].rounds_data || []).forEach(rr => {
      const localRound = allRounds.find(r => Number(r.round) === Number(rr.round));
      if (!localRound) return;
      (rr.games || []).forEach(rg => {
        const lg = (localRound.games || []).find(g => Number(g.court || 0) === Number(rg.court || 0));
        if (!lg) return;
        if (rg.score && JSON.stringify(lg.score || null) !== JSON.stringify(rg.score)) { lg.score = rg.score; lg.score_status = rg.score_status || 'scoring'; changed = true; }
        if (rg.winner && lg.winner !== rg.winner) { lg.winner = rg.winner; lg.winners = (rg.winner === 'L' ? lg.pair1 : lg.pair2).slice(); changed = true; }
      });
    });
    if (changed) {
      if (typeof saveSnapshot === 'function') saveSnapshot();
      if (typeof checkAllWinnersMarked === 'function') checkAllWinnersMarked();
      const page = document.getElementById('roundsPage');
      if (page && page.style.display !== 'none' && typeof showRound === 'function' && typeof currentRoundIndex !== 'undefined') showRound(currentRoundIndex);
    }
    return changed;
  } catch(e) { return false; }
}

async function saveRoundsToDb() { await dbSyncRoundsData(); }

async function flushLiveSession() {
  try {
    const club = getMyClub();
    if (!club.id) return;
  } catch(e) { console.warn('flushLiveSession error:', e.message); }
}

async function cleanupLiveSessions() {
  if (window.SCSRoundStorage?.networkPaused()) return;
  try {
    // Build 603: automatically finish abandoned LIVE sessions after 3 hours
    // without activity. updated_at is refreshed whenever round/session data is
    // synced, so an actively used long session is not closed.
    let clubIds = [];
    if (typeof dbGetMyJoinedClubIds === 'function') {
      clubIds = await dbGetMyJoinedClubIds().catch(() => []);
    }
    const club = (typeof getMyClub === 'function') ? getMyClub() : { id: null };
    if (club && club.id && !clubIds.includes(club.id)) clubIds.push(club.id);
    clubIds = [...new Set(clubIds.filter(Boolean))];
    if (!clubIds.length) return;

    const filter = clubIds.length === 1
      ? `club_id=eq.${clubIds[0]}&status=eq.live&select=id,club_id,created_at,updated_at`
      : `club_id=in.(${clubIds.join(',')})&status=eq.live&select=id,club_id,created_at,updated_at`;
    const rows = await sbGet('sessions', filter).catch(() => []);
    if (!rows || !rows.length) return;

    const staleBefore = Date.now() - (3 * 60 * 60 * 1000);
    const stale = rows.filter(sess => {
      const lastActivity = Date.parse(sess.updated_at || sess.created_at || '');
      return Number.isFinite(lastActivity) && lastActivity < staleBefore;
    });
    if (!stale.length) return;

    const now = new Date().toISOString();
    for (const sess of stale) {
      await sbPatch('sessions', `id=eq.${sess.id}&status=eq.live`, {
        status: 'completed',
        updated_at: now
      }).catch(() => {});
      if (sess.club_id) {
        await sbPatch('memberships', `club_id=eq.${sess.club_id}&is_playing=eq.true`, { is_playing: false }).catch(() => {});
      }
    }
  } catch(e) { console.warn('cleanupLiveSessions error:', e.message); }
}

// ─────────────────────────────────────────────────────────────
//  GLOBAL PLAYERS CACHE
// ─────────────────────────────────────────────────────────────

const CACHE_GLOBAL_PLAYERS = 'kbrr_cache_global_players';

async function syncGlobalPlayersCache() {
  try {
    const club = getMyClub();
    if (!club.id) return;
    const raw = await sbGet('memberships',
      `club_id=eq.${club.id}&order=nickname.asc&select=nickname,club_rating,players(gender,global_rating)`);
    const players = raw.map(m => ({
      displayName: m.nickname,
      gender:      m.players?.gender            || 'Male',
      rating:      parseFloat(m.players?.global_rating) || 1.0,
      clubRating:  parseFloat(m.club_rating)            || 1.0
    }));
    localStorage.setItem(CACHE_GLOBAL_PLAYERS, JSON.stringify(players));
  } catch(e) {}
}

function getGlobalPlayersCache() {
  try { return JSON.parse(localStorage.getItem(CACHE_GLOBAL_PLAYERS) || '[]'); }
  catch(e) { return []; }
}

// ─────────────────────────────────────────────────────────────
//  CONNECTIVITY CHECK
// ─────────────────────────────────────────────────────────────

async function dbIsOnline() {
  await window.SCSRoundStorage?.waitForNetwork();
  try {
    const res = await fetch(WORKER_URL + '/health');
    return res.ok;
  } catch { return false; }
}

async function dbDeleteClub(clubId) {
  await sbDelete('clubs', `id=eq.${clubId}`);
}

// ─────────────────────────────────────────────────────────────
//  SESSION SLOT TRACKING
// ─────────────────────────────────────────────────────────────

const SESSION_ID         = `session_${Date.now()}_${Math.random().toString(36).slice(2,7)}`;
const SESSION_TIMEOUT_MS = 6 * 60 * 60 * 1000;

async function dbClaimSessionSlots(playerNames) {
  if(window.SCSRoundStorage?.isLocal()) return;
  const club = getMyClub();
  if (!club.id) return;
  for (const name of playerNames) {
    try {
      await sbPatch('memberships', `club_id=eq.${club.id}&nickname=ilike.${encodeURIComponent(name)}`, { is_playing: true });
    } catch(e) {}
  }
  localStorage.removeItem(CACHE_PLAYERS);
  localStorage.removeItem(CACHE_TIMESTAMP);
}

async function dbReleaseSessionSlots(playerNames) {
  if(window.SCSRoundStorage?.isLocal()) return;
  for (const name of playerNames) {
    try {
      const club = getMyClub();
      await sbPatch('memberships', `club_id=eq.${club.id}&nickname=ilike.${encodeURIComponent(name)}`, { is_playing: false });
    } catch(e) {}
  }
  localStorage.removeItem(CACHE_PLAYERS);
  localStorage.removeItem(CACHE_TIMESTAMP);
}

async function dbReleaseMySession() {
  if(window.SCSRoundStorage?.isLocal()) return;
  try {
    const club = getMyClub();
    if (club.id) await sbPatch('memberships', `club_id=eq.${club.id}&is_playing=eq.true`, { is_playing: false });
  } catch(e) {}
}

async function dbGetUnavailablePlayers() {
  try {
    const club = getMyClub();
    if (!club.id) return new Set();
    const rows = await sbGet('memberships', `club_id=eq.${club.id}&is_playing=eq.true&select=nickname`);
    return new Set((rows || []).map(r => r.nickname.trim().toLowerCase()));
  } catch(e) { return new Set(); }
}

// ─────────────────────────────────────────────────────────────
//  PLAYER SESSIONS
// ─────────────────────────────────────────────────────────────

async function savePlayerSession(playerName, entry) {
  const existing = await sbGet('player_sessions',
    `player_name=ilike.${encodeURIComponent(playerName)}&date=eq.${entry.date}&select=id`);
  if (existing && existing.length) {
    await sbPatch('player_sessions',
      `player_name=ilike.${encodeURIComponent(playerName)}&date=eq.${entry.date}`,
      { wins: entry.wins, losses: entry.losses, rating: entry.rating });
  } else {
    await sbPost('player_sessions', {
      player_name: playerName, date: entry.date,
      wins: entry.wins, losses: entry.losses, rating: entry.rating
    });
  }
}

async function getPlayerSessions(playerName) {
  try {
    return await sbGet('player_sessions',
      `player_name=ilike.${encodeURIComponent(playerName)}&order=date.desc&limit=10`) || [];
  } catch(e) { return []; }
}

// ─────────────────────────────────────────────────────────────
//  SESSION HEARTBEAT
// ─────────────────────────────────────────────────────────────

var _heartbeatTimer = null;
var _externalScoreTimer = null;

function startSessionHeartbeat() {
  stopSessionHeartbeat();
  if(window.SCSRoundStorage?.isLocal())return;
  if (typeof scsAutoNetworkEnabled === 'function' && !scsAutoNetworkEnabled()) return;
  _externalScoreTimer = setInterval(() => { if (typeof scsAutoNetworkEnabled === 'function' && !scsAutoNetworkEnabled()) return; if (typeof dbPullExternalLiveScores === 'function') dbPullExternalLiveScores(); }, (typeof scsAutoInterval === 'function' ? scsAutoInterval('live') : 5) * 1000);
  _heartbeatTimer = setInterval(async () => {
    if (typeof scsAutoNetworkEnabled === 'function' && !scsAutoNetworkEnabled()) return;
    const sessionId = (typeof getMySessionId === 'function') ? getMySessionId() : null;
    if (!sessionId) { stopSessionHeartbeat(); return; }
    try { await sbPatch('sessions', `id=eq.${sessionId}`, { updated_at: new Date().toISOString() }); }
    catch(e) {}
  }, (typeof scsAutoInterval === 'function' ? scsAutoInterval('heartbeat') : 60) * 1000); // settings-controlled heartbeat
}

function stopSessionHeartbeat() {
  if (_heartbeatTimer) { clearInterval(_heartbeatTimer); _heartbeatTimer = null; }
  if (_externalScoreTimer) { clearInterval(_externalScoreTimer); _externalScoreTimer = null; }
}

// ─────────────────────────────────────────────────────────────
//  ROUND MATCH RECORDING
// ─────────────────────────────────────────────────────────────

async function dbRecordRoundMatches(updatedRatings) {
  if(window.SCSRoundStorage?.isLocal()) return;
  try {
    const club = getMyClub();
    if (!club.id) return;
    const sessionId = (typeof getMySessionId === 'function') ? getMySessionId() : null;
    const rounds    = (typeof allRounds !== 'undefined') ? allRounds : [];
    if (!rounds.length) return;
    let completedRound = null;
    for (let i = rounds.length - 1; i >= 0; i--) {
      const games = rounds[i].games || [];
      if (games.some(g => g.winner)) { completedRound = rounds[i]; break; }
    }
    if (!completedRound) return;
    const games       = completedRound.games || [];
    const roundNumber = completedRound.round || 0;
    const allNicknames = [...new Set(games.flatMap(g => [...(g.pair1||[]), ...(g.pair2||[])]).filter(Boolean))];
    if (!allNicknames.length) return;
    const members = await sbGet('memberships', `club_id=eq.${club.id}&select=player_id,nickname,club_rating,club_points`).catch(() => []);
    const mMap = {};
    (members || []).forEach(m => { mMap[m.nickname.trim().toLowerCase()] = m; });
    const pid = n => mMap[(n||'').trim().toLowerCase()]?.player_id || null;
    for (const game of games) {
      if (!game.winner) continue;
      const p1 = game.pair1 || [], p2 = game.pair2 || [];
      const newR  = updatedRatings.filter(u => [...p1,...p2].includes(u.name));
      const delta = newR.length ? Math.abs(Math.round(newR[0].activeRating * 10) / 10 - (parseFloat(mMap[(newR[0].name||'').trim().toLowerCase()]?.club_rating) || 1.0)) : 0;
      await sbPost('matches', {
        session_id: sessionId, club_id: club.id, round_number: roundNumber,
        pair1_player1: pid(p1[0]), pair1_player2: pid(p1[1]),
        pair2_player1: pid(p2[0]), pair2_player2: pid(p2[1]),
        winner_pair:   game.winner === 'L' ? 'pair1' : 'pair2',
        rating_delta:  delta, points_delta: delta
      }).catch(() => {});
    }
    const pids = [...new Set(Object.values(mMap).map(m => m.player_id).filter(Boolean))];
    for (const p of pids) {
      const allM = await sbGet('memberships', `player_id=eq.${p}&select=club_rating`).catch(() => []);
      if (allM.length) {
        const avg = allM.reduce((s, m) => s + (parseFloat(m.club_rating) || 1.0), 0) / allM.length;
        await sbPatch('players', `id=eq.${p}`, { global_rating: Math.round(avg * 10) / 10 }).catch(() => {});
      }
    }
  } catch(e) { console.warn('dbRecordRoundMatches error:', e.message); }
}

window.scsFlushTournamentCloudSaves=scsFlushTournamentCloudSaves;

/* V407 unified public persistence gateway. All tournament formats use the
   same writer/outbox; existing family-aware loaders are retained underneath. */
window.SCSTournamentStore=Object.freeze({
 save:(format,state)=>dbSaveTournamentState(format,state),
 queue:(format,state)=>scsQueueTournamentCloudSave(format,state),
 sync:()=>scsFlushTournamentCloudSaves(),
 load:(id)=>dbLoadTournamentById(id),
 list:(statuses)=>dbListClubTournaments(statuses),
 loadLatest:(format)=>dbLoadLatestTournament(format)
});
