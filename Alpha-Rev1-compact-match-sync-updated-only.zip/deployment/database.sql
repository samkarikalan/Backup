-- Additive match-level transport. Existing snapshots remain for setup/backward compatibility.
create sequence if not exists public.scs_live_match_revision;
create table if not exists public.tournament_live_matches (
 id uuid primary key default gen_random_uuid(),
 tournament_id uuid not null, -- retained as a tombstone when an event is deleted
 club_id uuid not null references public.clubs(id) on delete cascade,
 match_key text not null,
 parent_key text not null,
 source_session_id uuid,
 source_round integer not null default 1,
 event jsonb not null default '{}'::jsonb,
 data jsonb not null default '{}'::jsonb,
 status text not null default 'pending' check(status in ('pending','assigned','playing','submitted','approved','removed')),
 court integer check(court is null or court>0),
 revision bigint not null default nextval('public.scs_live_match_revision'),
 updated_at timestamptz not null default clock_timestamp(),
 source_fingerprint text,
 last_operation text,
 unique(tournament_id,match_key)
);
alter table public.tournament_live_matches enable row level security;
revoke all on public.tournament_live_matches from public,anon,authenticated;
grant select,insert,update,delete on public.tournament_live_matches to service_role;
grant usage,select on sequence public.scs_live_match_revision to service_role;
create index if not exists scs_live_matches_club_revision on public.tournament_live_matches(club_id,revision);
create index if not exists scs_live_matches_session on public.tournament_live_matches(source_session_id);
create unique index if not exists scs_live_match_court on public.tournament_live_matches(club_id,parent_key,court) where court is not null and status in ('assigned','playing','submitted');
create index if not exists memberships_account_club_idx on public.memberships(user_account_id,club_id);
create index if not exists sessions_club_status_owner_updated_idx on public.sessions(club_id,status,started_by,updated_at desc);

create or replace function public.scs_live_match_stamp() returns trigger language plpgsql set search_path='' as $$
begin
 perform pg_catalog.pg_advisory_xact_lock(736271938);
 if tg_op='INSERT' then new.revision:=nextval('public.scs_live_match_revision');new.updated_at:=clock_timestamp();return new;end if;
 if new.data is distinct from old.data or new.event is distinct from old.event or new.status is distinct from old.status or new.court is distinct from old.court or new.source_session_id is distinct from old.source_session_id then
  new.revision:=nextval('public.scs_live_match_revision');new.updated_at:=clock_timestamp();
 else new.revision:=old.revision;new.updated_at:=old.updated_at;end if;return new;
end $$;
drop trigger if exists scs_live_match_stamp on public.tournament_live_matches;
create trigger scs_live_match_stamp before insert or update on public.tournament_live_matches for each row execute function public.scs_live_match_stamp();

create or replace function public.scs_seed_live_matches(p_event uuid) returns void language plpgsql security invoker set search_path='' as $$
declare e record; m jsonb; g jsonb; entries jsonb; pairs jsonb; result jsonb; ev jsonb; fingerprint text; session_id uuid; round_no integer; st text; court_no integer; a text; b text; source text; parent text;
begin
 perform pg_catalog.pg_advisory_xact_lock(736271938);
 select * into e from public.tournaments where id=p_event;
 if not found or coalesce((e.state->>'_scsMainTournament')::boolean,false) then return;end if;
 ev:=jsonb_build_object('_scsCloudTournamentId',e.id,'_scsClientTournamentId',e.state->>'_scsClientTournamentId','_scsGroupEventId',e.state->>'_scsGroupEventId','_scsKoEventId',e.state->>'_scsKoEventId','_scsGroupKnockoutStage',e.state->'_scsGroupKnockoutStage','_scsParentTournamentId',e.state->>'_scsParentTournamentId','title',e.title,'format',e.format,'scoringRules',e.state->'scoringRules','sport',e.state->>'sport','courtNumbers',e.state->'courtNumbers');
 parent:=coalesce(e.state->>'_scsParentTournamentId',e.state->>'_scsKoMainId',e.state->>'_scsTeamMainId',e.id::text);
 parent:=coalesce((select t.id::text from public.tournaments t where t.club_id=e.club_id and coalesce((t.state->>'_scsMainTournament')::boolean,false) and parent in (t.id::text,t.state->>'id',t.state->>'_scsClientTournamentId') limit 1),parent);
 ev:=ev||jsonb_build_object('_scsParentTournamentId',parent);
 entries:=case when e.format='team' then coalesce((select jsonb_agg(x) from jsonb_array_elements(coalesce(e.state->'encounters','[]'::jsonb)) encounter cross join lateral jsonb_array_elements(coalesce(encounter->'matches','[]'::jsonb)) x),'[]'::jsonb) else coalesce(e.state->'matches','[]'::jsonb) end;
 for m in select value from jsonb_array_elements(entries) loop
  if m->>'id' is null then continue;end if;
  g:=null;session_id:=null;round_no:=1;
  if e.format='knockout' then
    a:=null;b:=null;
    for source in select unnest(array['a','b']) loop
     if m->>source ~ '^\d+$' then select x->>'name' into st from jsonb_array_elements(coalesce(e.state->'entries','[]'::jsonb)) x where x->>'id'=m->>source limit 1;
     else
      select jsonb_build_object('winner',case when lm.data->>'winner'='L' then array_to_string(array(select jsonb_array_elements_text(lm.data->'pair1')),' / ') else array_to_string(array(select jsonb_array_elements_text(lm.data->'pair2')),' / ') end,'loser',case when lm.data->>'winner'='L' then array_to_string(array(select jsonb_array_elements_text(lm.data->'pair2')),' / ') else array_to_string(array(select jsonb_array_elements_text(lm.data->'pair1')),' / ') end) into result from public.tournament_live_matches lm where lm.tournament_id=e.id and lm.match_key=substring(m->>source from 2) and lm.status='approved';
      result:=coalesce(result,e.state->'results'->substring(m->>source from 2));st:=case when left(m->>source,1)='L' then result->>'loser' else result->>'winner' end;end if;
     if source='a' then a:=st;else b:=st;end if;
    end loop;
    pairs:=jsonb_build_array(case when a is null then '[]'::jsonb else to_jsonb(string_to_array(a,' / ')) end,case when b is null then '[]'::jsonb else to_jsonb(string_to_array(b,' / ')) end);
   select ss.id,(rr->>'round')::integer,gg into session_id,round_no,g from public.sessions ss cross join lateral jsonb_array_elements(ss.rounds_data) rr cross join lateral jsonb_array_elements(coalesce(rr->'games','[]'::jsonb)) gg
   where ss.club_id=e.club_id and ss.started_by='__SCS_TOURNAMENT_COURT_CENTER__' and rr->'tournament'->>'_scsCloudTournamentId'=e.id::text and gg->>'tournament_match'=m->>'id' and gg->'pair1'=pairs->0 and gg->'pair2'=pairs->1 order by ss.updated_at desc limit 1;
   if g is null then
    g:=jsonb_build_object('tournament_match',m->>'id','pair1',pairs->0,'pair2',pairs->1,'winnerEnabled',true);
   end if;
  else
   pairs:=case when e.format='group' then jsonb_build_array(coalesce(e.state->'assignments'->(m->>'a'),'[]'::jsonb),coalesce(e.state->'assignments'->(m->>'b'),'[]'::jsonb)) else coalesce(m->'pairs','[[],[]]'::jsonb) end;
   g:=jsonb_build_object('tournament_match',m->>'id','pair1',pairs->0,'pair2',pairs->1,'court',m->'court','score',m->'score','winner',m->'winner','score_status',case when m->>'status'='score_ready' then 'scored' when m->>'status'='playing' then 'scoring' else null end,'court_center_status',m->>'status','conduct_finished',m->'conduct_finished','started_at',m->'startedAt','winnerEnabled',true);
  end if;
  result:=e.state->'results'->(m->>'id');
  st:=case when result is not null or g->>'court_center_status'='approved' or m->>'status'='approved' then 'approved' when g->>'score_status'='scored' then 'submitted' when g->>'score_status'='scoring' or g->>'court_center_status'='playing' then 'playing' when g->>'court' is not null then 'assigned' else 'pending' end;
  if e.status='completed' then st:=case when st='approved' then st else 'removed' end;end if;
  court_no:=case when st in ('assigned','playing','submitted') then nullif(g->>'court','')::integer else null end;
  if jsonb_typeof(g->'score')='object' then g:=jsonb_set(g,'{score}',(g->'score')-'history');end if;
  fingerprint:=md5(g::text||coalesce(result::text,''));
  insert into public.tournament_live_matches(tournament_id,club_id,match_key,parent_key,source_session_id,source_round,event,data,status,court,source_fingerprint)
   values(e.id,e.club_id,m->>'id',parent,session_id,coalesce(round_no,1),ev,g,st,court_no,fingerprint)
  on conflict(tournament_id,match_key) do update set event=excluded.event,parent_key=excluded.parent_key,
   data=case when tournament_live_matches.status='approved' or tournament_live_matches.source_fingerprint=excluded.source_fingerprint then tournament_live_matches.data else excluded.data end,
   status=case when tournament_live_matches.status='approved' or tournament_live_matches.source_fingerprint=excluded.source_fingerprint then tournament_live_matches.status else excluded.status end,
   court=case when tournament_live_matches.status='approved' or tournament_live_matches.source_fingerprint=excluded.source_fingerprint then tournament_live_matches.court else excluded.court end,
   source_session_id=coalesce(excluded.source_session_id,tournament_live_matches.source_session_id),source_round=excluded.source_round,source_fingerprint=excluded.source_fingerprint;
 end loop;
 update public.tournament_live_matches lm set status='removed',court=null where lm.tournament_id=e.id and not exists(select 1 from jsonb_array_elements(entries) x where x->>'id'=lm.match_key) and lm.status<>'removed';
end $$;

create or replace function public.scs_live_source_changed() returns trigger language plpgsql security invoker set search_path='' as $$
declare event_id uuid; r jsonb;
begin
 if tg_table_name='tournaments' then
  if tg_op='UPDATE' and new.state is not distinct from old.state and new.status is not distinct from old.status and new.title is not distinct from old.title then return new;end if;
  perform public.scs_seed_live_matches(new.id);
 else
  if tg_op='UPDATE' and new.rounds_data is not distinct from old.rounds_data then return new;end if;
  for r in select value from jsonb_array_elements(coalesce(new.rounds_data,'[]'::jsonb)) loop
   if r->'tournament'->>'_scsCloudTournamentId' ~ '^[0-9a-fA-F-]{36}$' then event_id:=(r->'tournament'->>'_scsCloudTournamentId')::uuid;perform public.scs_seed_live_matches(event_id);end if;
  end loop;
 end if;return new;
end $$;
drop trigger if exists scs_live_source_changed on public.tournaments;
create trigger scs_live_source_changed after insert or update on public.tournaments for each row execute function public.scs_live_source_changed();
drop trigger if exists scs_live_source_changed on public.sessions;
create trigger scs_live_source_changed after insert or update on public.sessions for each row execute function public.scs_live_source_changed();

create or replace function public.scs_apply_live_match(p_id uuid,p_revision bigint,p_operation text,p_patch jsonb,p_request text) returns public.tournament_live_matches language plpgsql security invoker set search_path='' as $$
declare m public.tournament_live_matches; allowed text[]; k text; numbers jsonb; parent record; event_id text;
begin
 perform pg_catalog.pg_advisory_xact_lock(736271938);
 select * into m from public.tournament_live_matches where id=p_id for update;
 if not found then raise exception 'Match not found' using errcode='P0002';end if;
 if m.last_operation=p_request then return m;end if;
 if m.status='approved' then raise exception 'Approved results cannot be changed' using errcode='23514';end if;
 if m.revision<>p_revision then raise exception 'Match changed. Refresh and retry' using errcode='40001';end if;
 if p_operation='assign' then
  allowed:=array['court','pair1','pair2','ccid','court_center_status','score_status','started_at','tournament_match','winnerEnabled'];
  if p_patch->'pair1' is distinct from m.data->'pair1' or p_patch->'pair2' is distinct from m.data->'pair2' then raise exception 'Fixture players changed' using errcode='23514';end if;
  if m.status not in ('pending','assigned') then raise exception 'Match already started' using errcode='23514';end if;
  select t.state into parent from public.tournaments t where t.club_id=m.club_id and coalesce((t.state->>'_scsMainTournament')::boolean,false) and m.parent_key in(t.id::text,t.state->>'id',t.state->>'_scsClientTournamentId') limit 1;
  event_id:=coalesce(m.event->>'_scsGroupEventId',m.event->>'_scsKoEventId',m.event->>'_scsClientTournamentId');
  numbers:=coalesce(parent.state->'courtAllocations'->event_id,m.event->'courtNumbers');
  if numbers is null or not exists(select 1 from jsonb_array_elements_text(numbers) n where n::integer=(p_patch->>'court')::integer) then raise exception 'Court is not allocated to this event' using errcode='23514';end if;
  m.court:=(p_patch->>'court')::integer;m.status:=case when p_patch->>'score_status'='scoring' then 'playing' else 'assigned' end;
 elsif p_operation='score' then
  allowed:=array['score','score_status','winner','conduct_finished'];
  if m.status not in ('assigned','playing','submitted') or m.court is null then raise exception 'Match is not assigned' using errcode='23514';end if;
  if p_patch->'score'->'names' is distinct from (m.data->'pair1')||(m.data->'pair2') then raise exception 'Score players do not match assignment' using errcode='23514';end if;
  m.status:=case when p_patch->>'winner' in ('L','R') then 'submitted' else 'playing' end;
  if m.data->'score'->>'finished'='true' and m.data->>'winner' is not null and (p_patch->'score'->>'finished' is distinct from 'true' or (m.data->'score'->'currentScore') is distinct from (p_patch->'score'->'currentScore') or (m.data->'score'->'completedSets') is distinct from (p_patch->'score'->'completedSets') or m.data->>'winner' is distinct from p_patch->>'winner') then raise exception 'A different finished result needs organizer review' using errcode='23514';end if;
 elsif p_operation='approve' then
  allowed:=array[]::text[];
  if m.status<>'submitted' or not coalesce((m.data->'score'->>'finished')::boolean,false) or m.data->>'winner' not in ('L','R') then raise exception 'Complete the score before approval' using errcode='23514';end if;
  m.status:='approved';m.court:=null;m.data:=m.data||jsonb_build_object('court',null,'court_center_status','approved');
 else raise exception 'Unknown match operation';end if;
 for k in select jsonb_object_keys(p_patch) loop if not k=any(allowed) then raise exception 'Unsupported match field: %',k;end if;end loop;
 update public.tournament_live_matches set data=m.data||p_patch,status=m.status,court=m.court,last_operation=p_request where id=m.id returning * into m;if p_operation='approve' then perform public.scs_seed_live_matches(m.tournament_id);end if;return m;
end $$;
revoke all on function public.scs_live_match_stamp() from public,anon,authenticated;
revoke all on function public.scs_seed_live_matches(uuid) from public,anon,authenticated;
revoke all on function public.scs_live_source_changed() from public,anon,authenticated;
revoke all on function public.scs_apply_live_match(uuid,bigint,text,jsonb,text) from public,anon,authenticated;
grant execute on function public.scs_seed_live_matches(uuid),public.scs_apply_live_match(uuid,bigint,text,jsonb,text) to service_role;
-- Backfill existing current events; no source record or result is deleted.
select public.scs_seed_live_matches(id) from public.tournaments where not coalesce((state->>'_scsMainTournament')::boolean,false);

create or replace function public.scs_live_event_deleted() returns trigger language plpgsql security invoker set search_path='' as $$ begin perform pg_catalog.pg_advisory_xact_lock(736271938);update public.tournament_live_matches set status='removed',court=null where tournament_id=old.id;return old;end $$;
revoke all on function public.scs_live_event_deleted() from public,anon,authenticated;
drop trigger if exists scs_live_event_deleted on public.tournaments;
create trigger scs_live_event_deleted before delete on public.tournaments for each row execute function public.scs_live_event_deleted();
