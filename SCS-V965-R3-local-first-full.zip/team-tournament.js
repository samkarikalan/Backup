(function(){
'use strict';
// Club encounters extend the Group Tournament round-robin pattern and share its Match Center.
const KEY='scs_team_tournament_v1';
let state={title:'',clubs:[],encounters:[],courtCount:1,serial:0,matchesPerEncounter:3},tab='fixtures',matchTab='waiting',assigning=null,viewOnly=false,selectedEncounterId=null;
let workerTeamStandings=null;
async function refreshWorkerTeamStandings(renderAfter){
 if(!state.encounters.length||!window.SCSTournamentEngine)return false;
 try{workerTeamStandings=(await SCSTournamentEngine.run('team-standings',{clubs:state.clubs,encounters:state.encounters})).standings;if(renderAfter)render();return true}
 catch(error){console.warn('Worker team standings unavailable:',error&&error.message||error);return false}
}
const root=()=>document.getElementById('scsTeamTournament');
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const save=()=>{if(!viewOnly){if(state._scsTeamMainId&&state._scsClientTournamentId)localStorage.setItem('scs_team_event_'+state._scsClientTournamentId,JSON.stringify(state));localStorage.setItem(KEY,JSON.stringify(state));if(typeof window.scsQueueTournamentCloudSave==='function')window.SCSTournamentStore.queue('team',state);if(state._scsTeamMainId)saveEventIndex()}};
let teamSaveBusy=false;
async function saveTeamTournamentNow(){
 if(viewOnly)return;
 const indicator=root()?.querySelector('[data-team-save-status]');
 if(teamSaveBusy)return;
 if(!String(state.title||'').trim()){if(indicator)indicator.textContent='Enter a tournament name first.';return;}
 teamSaveBusy=true;
 const btn=root()?.querySelector('[data-team-save]');
 if(btn)btn.disabled=true;
 if(indicator)indicator.textContent=(typeof t === 'function' ? t('scsSaving') : "Saving…");
 try{
  localStorage.setItem(KEY,JSON.stringify(state));
  if(typeof window.dbSaveTournamentState!=='function')throw Error('Server save is unavailable. Saved on this device only.');
  const id=await window.SCSTournamentStore.save('team',state);if(id){state._scsCloudTournamentId=id;localStorage.setItem(KEY,JSON.stringify(state));if(state._scsTeamMainId){localStorage.setItem('scs_team_event_'+state._scsClientTournamentId,JSON.stringify(state));saveEventIndex();}}
  if(!id)throw Error('Server save unavailable. Check your club login and connection. Saved on this device only.');
  if(indicator)indicator.textContent=window.SCSTournamentLocal?SCSTournamentLocal.describe():'✓ Saved to server';
 }catch(err){if(indicator)indicator.textContent='⚠ '+(err?.message||'Server save failed; local copy retained.');}
 finally{teamSaveBusy=false;if(btn)btn.disabled=false;}
}
function load(){if(viewOnly)return;try{state=JSON.parse(localStorage.getItem(KEY))||state}catch(e){}state.clubs||=[];state.encounters||=[];state.courtCount||=1;state.serial||=0;state.matchesPerEncounter=[3,5,7,9].includes(Number(state.matchesPerEncounter))?Number(state.matchesPerEncounter):3}
const MAIN_KEY='scs_team_main_tournament_v1';
let main=null, mainMode=false;
let activeEventId=null;
const activeEventKey=mainId=>'scs_team_active_event_'+String(mainId||'');
function rememberActiveEvent(id){
 if(!main||!main.events?.some(e=>e.id===id))return;
 activeEventId=id;
 main.activeEventId=id;
 try{localStorage.setItem(activeEventKey(main._scsClientTournamentId),id)}catch(_){}
 persistMain();
}
function restoreActiveEvent(){
 if(!main)return null;
 let stored=null;
 try{stored=localStorage.getItem(activeEventKey(main._scsClientTournamentId))}catch(_){}
 const ids=(main.events||[]).map(e=>e.id).filter(Boolean);
 const selected=[main.activeEventId,stored,activeEventId].find(id=>ids.includes(id))||ids[0]||null;
 if(selected){if(activeEventId!==selected||main.activeEventId!==selected)rememberActiveEvent(selected);else activeEventId=selected;}
 else {activeEventId=null;main.activeEventId=null;}
 return activeEventId;
}

function newId(){return typeof crypto!=='undefined'&&crypto.randomUUID?crypto.randomUUID():'scs-'+Date.now()+'-'+Math.random().toString(36).slice(2)}
function persistMain(){
 if(!main||viewOnly)return;main._scsTournamentFormat='team';
 localStorage.setItem(MAIN_KEY,JSON.stringify(main));
 if(typeof window.scsQueueTournamentCloudSave==='function')window.SCSTournamentStore.queue('team',main);
}
function saveEventIndex(){if(viewOnly)return false;
 if(!main||!state._scsTeamMainId)return;
 let entry=main.events.find(e=>e.id===state._scsClientTournamentId);
 if(!entry){entry={id:state._scsClientTournamentId};main.events.push(entry)}
 entry.title=state.title||'New Event';
 entry.clubs=state.clubs.map(c=>c.name);
 entry.completed=state.encounters.reduce((n,e)=>n+(e.matches||[]).filter(m=>m.status==='approved').length,0);
 entry.matches=state.encounters.reduce((n,e)=>n+(e.matches||[]).length,0);
 entry.cloudId=state._scsCloudTournamentId||entry.cloudId||'';
 entry.updatedAt=new Date().toISOString();
 persistMain();
}
function openMain(){
 restoreActiveEvent();
 mainMode=true;tab='home';selectedEncounterId=null;
 if(!root()){let d=document.createElement('div');d.id='scsTeamTournament';d.className='scs-gt-overlay scs-team-overlay';document.body.appendChild(d)}
 render();
}
let creatingMain=false;
function createMain(){if(viewOnly)return false;
 viewOnly=false;creatingMain=true;mainMode=true;main=null;
 if(!root()){let d=document.createElement('div');d.id='scsTeamTournament';d.className='scs-gt-overlay scs-team-overlay';document.body.appendChild(d)}
 render();
}
function submitMain(){if(viewOnly)return false;
 const field=root()?.querySelector('[data-main-name]');
 const name=field?.value.trim();
 if(!name){field?.focus();root()?.querySelector('[data-main-error]')?.removeAttribute('hidden');return}
 main={title:name,_scsMainTournament:true,_scsClientTournamentId:newId(),events:[],createdAt:new Date().toISOString()};
 creatingMain=false;
 persistMain();
 if(typeof window.dbSaveTournamentState==='function')window.SCSTournamentStore.save('team',main).then(id=>{if(id){main._scsCloudTournamentId=id;persistMain()}}).catch(e=>console.warn('Main tournament save:',e));
 openMain();
}
function mainNameForm(){return window.ScsApi.events.createForm()}

let creatingEvent=false;
function eventNameForm(){return window.ScsApi.events.eventForm({parentTitle:main.title})}

function addEvent(){if(viewOnly)return false;
 if(viewOnly||!main)return;
 creatingEvent=true;mainMode=true;render();
}
function submitEvent(){if(viewOnly)return false;
 if(!main||viewOnly)return;
 const field=root()?.querySelector('[data-event-name]');
 const name=field?.value.trim();
 if(!name){field?.focus();root()?.querySelector('[data-event-error]')?.removeAttribute('hidden');return}
 state={title:name,clubs:[],encounters:[],courtCount:1,serial:0,matchesPerEncounter:3,
 _scsClientTournamentId:newId(),_scsTeamMainId:main._scsClientTournamentId,
 _scsParentTournamentId:main._scsClientTournamentId,_scsParentTournamentTitle:main.title};
 creatingEvent=false;mainMode=false;tab='setup';
 rememberActiveEvent(state._scsClientTournamentId);
 save();
 if(typeof window.dbSaveTournamentState==='function'){
  const eventId=state._scsClientTournamentId;
  const snapshot=JSON.parse(JSON.stringify(state));
  window.SCSTournamentStore.save('team',snapshot).then(id=>{
   if(!id)return;
   const entry=main?.events.find(e=>e.id===eventId);
   if(entry){entry.cloudId=id;persistMain()}
   if(state._scsClientTournamentId===eventId){state._scsCloudTournamentId=id;saveEventIndex()}
  }).catch(e=>console.warn('New event save:',e));
 }
 render();
}
async function openEvent(id){if(viewOnly)return false;
 const event=main?.events.find(e=>e.id===id);if(!event)return;
 let saved=null;
 if(event.cloudId&&typeof window.dbLoadTournamentById==='function'){
  try{const row=await window.dbLoadTournamentById(event.cloudId);saved=row?.state||null;if(saved)saved._scsCloudTournamentId=row.id}catch(e){console.warn('Event load',e)}
 }
 if(!saved){try{saved=JSON.parse(localStorage.getItem('scs_team_event_'+id)||'null')}catch(_){}}
 if(!saved){alert('This event is not available on this device yet. Connect to the server and try again.');return}
 state=saved;state._scsTeamMainId=main._scsClientTournamentId;state._scsParentTournamentId=main._scsClientTournamentId;state._scsParentTournamentTitle=main.title;
 rememberActiveEvent(id);
 localStorage.setItem(KEY,JSON.stringify(state));
 mainMode=false;tab=state.encounters?.length?'fixtures':'setup';render();
}
function open(mode,viewState){
 if(root())root().hidden=false;
 if(mode!=='new'){creatingEvent=false;creatingMain=false;}
 // Explicit selection must replace the last event from a different parent.
 if(mode!=='view'&&viewState)localStorage.setItem(KEY,JSON.stringify(viewState));
 viewOnly=mode==='view';if(viewOnly){creatingEvent=false;creatingMain=false;selectedEncounterId=null}
 if(viewOnly&&viewState){
  // A viewer must use the selected server snapshot, not the organizer's local tournament.
  state=JSON.parse(JSON.stringify(viewState));
  state.clubs||=[];state.encounters||=[];
  main=null;mainMode=false;activeEventId=null;assigning=null;
  if(!root()){let d=document.createElement('div');d.id='scsTeamTournament';d.className='scs-gt-overlay scs-team-overlay';document.body.appendChild(d)}
  tab=state.encounters.length?'fixtures':'setup';render();return;
 }
 load();
 if(mode==='new'){createMain();return}
 try{const stored=JSON.parse(localStorage.getItem(MAIN_KEY)||'null');if(stored?._scsMainTournament)main=stored}catch(_){}
 if(state._scsMainTournament){main=state;localStorage.setItem(MAIN_KEY,JSON.stringify(main))}else if(state._scsTeamMainId&&main&&state._scsTeamMainId!==main._scsClientTournamentId){main=null}
 if(main){restoreActiveEvent();openMain();return}
 // Legacy standalone Team Tournaments remain accessible.
 mainMode=false;
 if(!root()){let d=document.createElement('div');d.id='scsTeamTournament';d.className='scs-gt-overlay scs-team-overlay';document.body.appendChild(d)}
 tab=state.encounters.length?'fixtures':'setup';render();
}
function close(){if(viewOnly){root()?.remove();if(typeof window.scsReturnToTournamentParent==='function')window.scsReturnToTournamentParent();return}if(creatingEvent){creatingEvent=false;mainMode=true;render();return}if(creatingMain){creatingMain=false;mainMode=false;root()?.remove();if(typeof window.scsReturnToTournamentParent==='function')window.scsReturnToTournamentParent();return}if(!mainMode&&state._scsTeamMainId&&main){saveEventIndex();mainMode=true;tab='home';render();return}root()?.remove();if(typeof window.scsReturnToTournamentParent==='function')window.scsReturnToTournamentParent()}
const allMatches=()=>state.encounters.flatMap(e=>e.matches);
const encounterFor=m=>state.encounters.find(e=>e.matches.includes(m));
const clubName=id=>state.clubs[id]?.name||'Club '+(id+1);
const matchName=m=>{let e=encounterFor(m);return clubName(e.a)+' vs '+clubName(e.b)+' · Doubles '+(m.index+1)};
function standingsData(){return SCSTournamentEngine.ensure('team-standings',{clubs:state.clubs,encounters:state.encounters},()=>{if(root()&&!root().hidden)render()})?.standings||[];}
const resultOf=(e,id)=>{const done=e.matches.filter(m=>m.status==='approved'&&(m.winner==='L'||m.winner==='R'));const own=done.filter(m=>(m.winner==='L'?e.a:e.b)===id).length;return {done:done.length,own,other:done.length-own,complete:e.matches.length>0&&done.length===e.matches.length}};
const matchOutcome=(m,id,e)=>m.status!=='approved'?'Pending':(m.winner==='L'?e.a:e.b)===id?'Won':'Lost';
const matchScore=m=>{const sets=m.score?.completedSets||[];return sets.length?sets.map(x=>(x.score||[]).join('–')).join(' | '):'—'};
let expandedStandings=new Set();
function standings(){const rows=standingsData();if(!rows.length)return '<p role="status">Connect to load official standings.</p>';return '<section class="scs-team-ranking"><h3>Club standings</h3><p class="scs-team-ranking-help">Rank: encounter wins → sets won → rally points → head-to-head · 2 points per approved doubles win</p>'+rows.map((r,pos)=>{const expanded=expandedStandings.has(r.i),encounters=state.encounters.filter(e=>e.a===r.i||e.b===r.i);return '<article class="scs-team-standing" style="--club-accent:'+esc(clubAccent(r.i))+'"><button type="button" class="scs-team-standing-head" data-standing="'+r.i+'" aria-expanded="'+expanded+'"><span class="scs-team-rank">'+(pos+1)+'</span><span class="scs-team-standing-info"><strong>'+esc(r.name)+'</strong><small>Encounters: Played '+r.played+' · Won '+r.w+' · Lost '+r.l+'</small><small>Doubles: Played '+(r.mw+r.ml)+' · Won '+r.mw+' · Lost '+r.ml+'</small></span><span class="scs-team-standing-points"><b>'+r.points+'</b><small>Points</small></span><span aria-hidden="true">'+(expanded?'⌃':'⌄')+'</span></button>'+(expanded?'<div class="scs-team-standing-history">'+(encounters.length?encounters.map(e=>{const opp=e.a===r.i?e.b:e.a,rs=resultOf(e,r.i);return '<div class="scs-team-opponent" style="--opponent-accent:'+esc(clubAccent(opp))+'"><div class="scs-team-opponent-head"><strong>vs '+esc(clubName(opp))+'</strong><span>'+(rs.complete?(rs.own>rs.other?'Won ':'Lost '):'In progress ')+rs.own+'–'+rs.other+'</span></div>'+e.matches.map(m=>'<div class="scs-team-result-line"><span>Doubles '+(m.index+1)+'</span><span>'+esc((m.pairs[e.a===r.i?0:1]||[]).join(' / ')||'Not selected')+'</span><span class="scs-team-result-status">'+matchOutcome(m,r.i,e)+' · '+esc(matchScore(m))+'</span></div>').join('')+'</div>'}).join(''):'<p>No encounters yet</p>')+'</div>':'')+'</article>'}).join('')+'</section>'}
function matrix(){
 const rows=standingsData(),rank=new Map(rows.map(r=>[r.i,r.rank]));
 return '<section class="scs-team-matrix"><h3>Round-robin results matrix</h3><p>Rank: encounter wins → sets won → rally points → head-to-head. Swipe horizontally; tap an encounter for doubles results.</p><div class="scs-team-matrix-scroll"><table class="scs-team-matrix-table"><thead><tr><th class="scs-team-matrix-sticky">Club</th>'+state.clubs.map((c,i)=>'<th style="--matrix-accent:'+esc(clubAccent(i))+'">'+esc(c.name)+'</th>').join('')+'<th>Encounter W–L</th><th>Doubles W–L</th><th>Match points</th><th>Sets W–L</th><th>Rally points F–A</th><th>Point diff.</th><th>Rank</th></tr></thead><tbody>'+state.clubs.map((c,i)=>{
  const row=rows.find(x=>x.i===i);
  return '<tr><th class="scs-team-matrix-sticky" style="--matrix-accent:'+esc(clubAccent(i))+'">'+esc(c.name)+'</th>'+state.clubs.map((other,j)=>{
   if(i===j)return '<td class="scs-team-matrix-self">╲</td>';
   const e=state.encounters.find(x=>(x.a===i&&x.b===j)||(x.a===j&&x.b===i));if(!e)return '<td>—</td>';
   const rs=resultOf(e,i),label=rs.complete?(rs.own>rs.other?'Won ':rs.own<rs.other?'Lost ':'Tied '):rs.done?rs.done+'/'+e.matches.length+' played':'Pending';
   return '<td><button class="scs-team-matrix-cell" data-matrix-encounter="'+esc(e.id)+'" aria-label="'+esc(clubName(i)+' versus '+clubName(j))+'"><small>'+esc(e.id)+'</small><strong>'+label+'</strong><span>'+rs.own+'–'+rs.other+'</span></button></td>';
  }).join('')+'<td>'+row.w+'–'+row.l+'</td><td>'+row.mw+'–'+row.ml+'</td><td>'+row.points+'</td><td>'+row.setsWon+'–'+row.setsLost+'</td><td>'+row.rallyFor+'–'+row.rallyAgainst+'</td><td>'+(row.rallyFor-row.rallyAgainst)+'</td><td>'+rank.get(i)+'</td></tr>';
 }).join('')+'</tbody></table></div></section>';
}
function matrixDetails(id){const e=state.encounters.find(x=>x.id===id);if(!e)return '';const rs=resultOf(e,e.a);return '<h3>'+clubLabel(e.a)+' vs '+clubLabel(e.b)+' · '+rs.own+'–'+rs.other+'</h3>'+e.matches.map(m=>'<div class="scs-team-matrix-detail-row"><strong>Doubles '+(m.index+1)+'</strong><span>'+esc((m.pairs[0]||[]).join(' / ')||'Not selected')+' vs '+esc((m.pairs[1]||[]).join(' / ')||'Not selected')+'</span><span>'+esc(m.status==='approved'?(m.winner==='L'?clubName(e.a):clubName(e.b))+' won · '+matchScore(m):m.status.replace(/_/g,' '))+'</span></div>').join('')}
let expandedClubs=new Set();
// Preserve the independent scroll position of every Team Tournament tab.
const teamScrollPositions=Object.create(null);
function rememberTeamScroll(){const sheet=root()?.querySelector('.scs-team-sheet');if(sheet)teamScrollPositions[tab]=sheet.scrollTop;}
function teamEventSetupIssues(){
 if(viewOnly||allMatches().some(m=>['playing','score_ready','approved'].includes(m.status)))return [];
 const issues=[],name=state.title;
 if(!String(name||'').trim())issues.push('Enter the event name.');
 const count=Number(state.matchesPerEncounter);
 if(![3,5,7,9].includes(count))issues.push('Choose the number of doubles matches per encounter.');
 if(state.clubs.length<2)issues.push('Add at least two club teams.');
 if(state.clubs.some(c=>!String(c.name||'').trim()||!Array.isArray(c.players)||c.players.length<count*2||c.players.some(p=>!String(p||'').trim())||new Set(c.players.map(p=>String(p).trim().toLocaleLowerCase())).size!==c.players.length))issues.push('Complete each club roster with at least '+(count*2)+' different players.');
 if(new Set(state.clubs.map(c=>String(c.name||'').trim().toLocaleLowerCase())).size!==state.clubs.length)issues.push('Choose different club teams.');
 if(!Number.isInteger(Number(state.courtCount))||Number(state.courtCount)<1)issues.push('Set a valid number of courts.');
 return issues;
}
function teamEventAssistSteps(){
 const count=Number(state.matchesPerEncounter),clubs=state.clubs;
 const clubsReady=clubs.length>=2&&clubs.every(c=>String(c.name||'').trim())&&new Set(clubs.map(c=>String(c.name||'').trim().toLocaleLowerCase())).size===clubs.length;
 const rostersReady=clubsReady&&clubs.every(c=>Array.isArray(c.players)&&c.players.length>=count*2&&c.players.every(p=>String(p||'').trim())&&new Set(c.players.map(p=>String(p).trim().toLocaleLowerCase())).size===c.players.length);
 const reveal=selector=>ScsApi.events.revealSetupField(root()?.querySelector(selector));
 return [
  {label:'Event name',done:!!String(state.title||'').trim(),run:()=>{const input=root()?.querySelector('#team-title');if(input)reveal('#team-title');else{const name=prompt('Event name',state.title||'');if(name?.trim()){state.title=name.trim().slice(0,120);save();render();}}}},
  {label:'Club teams',done:clubsReady,run:()=>reveal('[data-add],.scs-team-club-list')},
  {label:'Player rosters',done:rostersReady,run:()=>reveal('[data-edit], [data-add]')},
  {label:'Matches per encounter',done:[3,5,7,9].includes(count),run:()=>reveal('#team-match-count')},
  {label:'Courts',done:Number.isInteger(Number(state.courtCount))&&state.courtCount>0,run:()=>{if(root()?.querySelector('[data-courts]'))reveal('[data-courts]');else{const raw=prompt('Number of courts',String(state.courtCount||1));if(raw===null)return;const n=Number(raw);if(Number.isInteger(n)&&n>=0&&n<=64){if(root()?._scsEventCourtPool?.active){root()._scsEventCourtPool.resize(n-root()._scsEventCourtPool.numbers.length);return;}state.courtCount=n;save();render();}}}}
 ];
}
function refreshTeamEventGate(){if(!mainMode&&main&&state._scsClientTournamentId&&!viewOnly)SCSEventCourtPool.connect(root(),{parent:()=>main,eventId:activeEventId||state._scsClientTournamentId,format:'team',state:()=>state,onChange:async numbers=>{state.courtNumbers=numbers;state.courtCount=numbers.length;save();render();}});if(!mainMode)ScsApi.events.gateNavigation(root(),'data-team-nav',teamEventSetupIssues(),['home','setup','clubs'].includes(tab),teamEventAssistSteps());}
function switchTeamTab(next){if(['fixtures','match','matrix','ranking'].includes(next)&&teamEventSetupIssues().length)next='home';if(next===tab)return;rememberTeamScroll();if(next==='clubs'&&tab!=='clubs'&&expandedClubs.size===0)state.clubs.forEach((_,i)=>expandedClubs.add(i));tab=next;const oldSheet=root()?.querySelector('.scs-team-sheet');if(oldSheet)oldSheet.remove();render();}
// Each club owns a separate roster of references to the existing Players Manager records.
const playerKey=name=>String(name||'').trim().toLocaleLowerCase();
const CLUB_PALETTE=['#438ef1','#22bc91','#b28af0','#e6a34f','#ee789d','#41b7d1','#b3c65a','#df8c6e'];
function clubColor(c,i){return Number.isInteger(c.colorIndex)?c.colorIndex:i;}
function clubAccent(id){const c=state.clubs[id]||{},n=clubColor(c,id);return c.color|| (n<CLUB_PALETTE.length?CLUB_PALETTE[n]:`hsl(${Math.round((n*137.508)%360)} 72% 65%)`)}
function clubStyle(id){return 'style="--team-accent:'+esc(clubAccent(id))+'"'}
function clubLabel(id){return '<span class="scs-team-club-label" '+clubStyle(id)+'>'+esc(clubName(id))+'</span>'}
function winnerClub(m){const e=encounterFor(m);return e&&(m.winner==='L'?e.a:m.winner==='R'?e.b:null)}
function winnerNote(m){const id=winnerClub(m);return id===null?'':'<div class="scs-team-winner-note" '+clubStyle(id)+'>🏆 Winner — '+esc(clubName(id))+'<small>'+esc(m.pairs[m.winner==='L'?0:1].join(' / '))+'</small></div>'}
function reservedByOtherClub(name,clubIndex){return state.clubs.some((c,i)=>i!==clubIndex&&c.players.some(p=>playerKey(p)===playerKey(name)));}
function setup(){return '<section class="scs-gt-card scs-team-setup"><div class="scs-team-intro"><span class="scs-team-step">01</span><div><h2>Create Team Tournament</h2></div></div><label class="scs-team-field">Tournament name<input id="team-title" value="'+esc(state.title)+'" placeholder="Club championship"></label><label class="scs-team-field">Doubles matches per club encounter<select id="team-match-count">'+[3,5,7,9].map(n=>'<option value="'+n+'" '+(state.matchesPerEncounter===n?'selected':'')+'>'+n+' doubles matches · '+(Math.floor(n/2)+1)+' wins required</option>').join('')+'</select></label><p class="scs-team-match-count-hint">Each player can play once against the same opposing club. Minimum '+(state.matchesPerEncounter*2)+' players per club.</p><div class="scs-team-section-title"><h3>Clubs <span class="scs-team-count">'+state.clubs.length+'</span></h3></div><div class="scs-team-club-list">'+(state.clubs.length?state.clubs.map((c,i)=>'<div class="scs-team-club scs-team-club-color-'+clubColor(c,i)+'" style="--club-accent:'+esc(clubAccent(i))+'"><div class="scs-team-club-head"><button type="button" class="scs-team-expand" data-expand="'+i+'" aria-expanded="'+expandedClubs.has(i)+'" aria-label="Toggle '+esc(c.name)+' players">'+(expandedClubs.has(i)?'⌃':'⌄')+'</button><div class="scs-team-club-name"><strong>'+esc(c.name)+'</strong><small>'+c.players.length+' players</small></div><button data-edit="'+i+'">Edit</button><button data-remove="'+i+'" aria-label="Remove club">×</button></div>'+(expandedClubs.has(i)?'<div class="scs-team-roster">'+c.players.map((name,j)=>'<div class="scs-team-roster-player"><span class="scs-team-player-number">'+(j+1)+'</span>'+playerRow(name)+'</div>').join('')+'</div>':'')+'</div>').join(''):'<div class="scs-team-empty"><strong>No clubs added yet</strong><small>Add a club and select players using Players Manager.</small></div>')+'</div><button class="scs-gt-secondary scs-team-add" data-add>＋ Add club and players</button></section>'}

function registry(){
 // Read the same master player sources used by SCS Players Manager.
 // Never write to these stores or mutate their objects.
 const names=[];
 const add=items=>(Array.isArray(items)?items:[]).forEach(p=>{
  const n=typeof p==='string'?p:p&&(p.name||p.displayName);
  if(n&&String(n).trim())names.push(String(n).trim());
 });
 try{if(typeof schedulerState!=='undefined'&&schedulerState)add(schedulerState.allPlayers)}catch(e){}
 for(const key of ['newImportHistory','newImportFavorites','schedulerPlayers']){
  try{add(JSON.parse(localStorage.getItem(key)||'[]'))}catch(e){}
 }
 try{if(window.SCSCourtCenter&&typeof window.SCSCourtCenter.playerNames==='function')add(window.SCSCourtCenter.playerNames())}catch(e){}
 return [...new Map(names.map(n=>[playerKey(n),n])).values()].sort((a,b)=>a.localeCompare(b));
}
function playerRow(name){return window.ScsApi.cards.player(name,teamLevelLabel(name));}
function hydratePlayerCards(){if(window.SCSTournamentPlayerLevel){window.SCSTournamentPlayerLevel.setRoster(root(),state.clubs.flatMap(c=>c.selectedPlayerDetails||[]));window.SCSTournamentPlayerLevel.hydrate(root());}}
let editingClub=null,clubDraft=null;
const teamPlayerLevels=new Map();
function teamLevel(name){const record=state.clubs.flatMap(c=>c.selectedPlayerDetails||[]).find(p=>playerKey(p.player)===playerKey(name));const v=record?.level??teamPlayerLevels.get(playerKey(name));return v!==null&&v!==undefined&&Number.isInteger(Number(v))&&Number(v)>=1&&Number(v)<=5?Number(v):null;}
function teamLevelLabel(name){const v=teamLevel(name);return '<span class="scs-team-level-badge scs-tournament-gender-level" data-tm-level-name="'+esc(name)+'" title="Player level">'+(v===null?'—':(state.clubs.flatMap(c=>c.selectedPlayerDetails||[]).find(p=>playerKey(p.player)===playerKey(name))?.gender||'').match(/female|woman|lady|women|^f$/i)?'L'+v:'M'+v)+'</span>'; }

function playersManagerReturned(){if(viewOnly)return false;
 if(!window.__scsTeamPlayersReturn)return false;
 window.__scsTeamPlayersReturn=false;
 if(root()){root().hidden=false;render();if(editingClub!==null)clubEditor(editingClub)}
 return true;
}
async function registeredClubChoices(){
 const parent=await scsResolveOrganizerClub();
 return dbGetSubClubs(parent.id);
}
async function registeredClubPlayers(id){
 if(!id||typeof sbGet!=='function')return [];
 const rows=await sbGet('memberships','club_id=eq.'+encodeURIComponent(id)+'&select=nickname,player_id');
 const ids=[...new Set((rows||[]).map(r=>r.player_id).filter(Boolean))];
 if(ids.length){
  try{
   const playerRows=await sbGet('players','id=in.('+ids.join(',')+')&select=id,level');
   const byId=new Map((playerRows||[]).map(r=>[r.id,r.level]));
   (rows||[]).forEach(r=>{const v=Number(byId.get(r.player_id));if(Number.isInteger(v)&&v>=1&&v<=5)teamPlayerLevels.set(playerKey(r.nickname),v)});
  }catch(err){console.warn('Player levels unavailable:',err)}
 }
 return [...new Map((rows||[]).map(r=>String(r.nickname||'').trim()).filter(Boolean).map(n=>[playerKey(n),n])).values()].sort((a,b)=>a.localeCompare(b));
}
function clubEditor(i){if(viewOnly)return false;
 if(state.encounters.length){alert('Club rosters are locked after fixtures have been generated.');return}
 const existing=state.clubs[i];
 const initial=Array.isArray(existing?.selectedPlayerDetails)?existing.selectedPlayerDetails:[];
 return window.SCSTournamentPlayersPage.open({selected:initial,onDone:function(players){
  const clubs=[...new Set(players.map(p=>p.subClub))];
  if(clubs.length!==1||!players.length){alert('Select players from one sub-club for this team.');return}
  const name=clubs[0],registeredClubId=null;
  if(state.clubs.some((c,j)=>j!==i&&c.name.toLowerCase()===name.toLowerCase())){alert('This sub-club is already registered.');return}
  const entry={...(existing||{}),name,players:players.map(p=>p.player),selectedPlayerDetails:players,registeredClubId,colorIndex:existing?.colorIndex??state.serial++};
  if(i===state.clubs.length)state.clubs.push(entry);else state.clubs[i]=entry;
  editingClub=null;clubDraft=null;save();render();
 }});
}

async function generate(){if(viewOnly)return false;const issues=teamEventSetupIssues();if(issues.length){alert('Complete Event setup: '+issues.join(' '));return false;}let name=(root().querySelector('#team-title')?.value??state.title??'').trim();if(!name||state.clubs.length<2||state.clubs.some(c=>c.players.length<state.matchesPerEncounter*2)){alert('Enter a tournament name and at least two clubs with '+(state.matchesPerEncounter*2)+' players each.');return}try{if(!window.SCSTournamentEngine)throw Error('Tournament engine is unavailable.');const generated=await SCSTournamentEngine.run('team-fixtures',{clubs:state.clubs,matchesPerEncounter:state.matchesPerEncounter});state.encounters=generated.encounters||[]}catch(error){alert(error.message||'Could not generate team fixtures.');return}state.title=name;workerTeamStandings=null;await refreshWorkerTeamStandings(false);selectedEncounterId=null;save();switchTeamTab('fixtures');render()}
function editEncounter(id){if(viewOnly)return false;
 const e=state.encounters.find(x=>x.id===id);if(!e)return;
 const modal=document.createElement('section');modal.className='scs-tm-entry-modal scs-team-pair-modal';
 const select=(side,m,slot)=>{
  const id=side==='L'?e.a:e.b,club=state.clubs[id],chosen=m.pairs[side==='L'?0:1][slot]||'';
  return '<div class="scs-team-pair-player"><span class="scs-team-pair-player-preview">'+(chosen?playerRow(chosen):'<span class="scs-team-pair-placeholder">Player '+(slot+1)+'</span>')+'</span><select aria-label="'+esc(club.name)+' player '+(slot+1)+'" data-pair="'+m.index+'-'+side+'-'+slot+'"><option value="">Select player</option>'+club.players.map(p=>'<option value="'+esc(p)+'" '+(p===chosen?'selected':'')+'>'+esc(p)+'</option>').join('')+'</select></div>';
 };
 const clubBlock=(id,side,m)=>'<section class="scs-team-pair-club" style="--team-accent:'+esc(clubAccent(id))+'"><h5>'+esc(clubName(id))+'</h5>'+select(side,m,0)+select(side,m,1)+'</section>';
 modal.innerHTML='<div class="scs-tm-entry-editor scs-team-club-editor scs-team-pair-editor"><h3>'+esc(clubName(e.a))+' vs '+esc(clubName(e.b))+'</h3><p class="scs-team-pair-help">Choose two different players from each club for every doubles match.</p><div class="scs-team-pair-scroll">'+e.matches.map(m=>'<article class="scs-team-pair-match"><h4>Doubles '+(m.index+1)+(m.status!=='pending'?' · '+esc(m.status):'')+'</h4>'+clubBlock(e.a,'L',m)+clubBlock(e.b,'R',m)+'</article>').join('')+'</div><div class="scs-tm-import-actions"><button data-cancel>Cancel</button><button class="scs-tm-primary" data-save>Done</button></div><p data-error role="status"></p></div>';
 root().appendChild(modal);
 if(window.SCSTeamPicker)SCSTeamPicker.bindTeamSelectors(modal,{row:playerRow});
 const selects=[...modal.querySelectorAll('select[data-pair]')];
 const refreshChoices=()=>{
  for(const sel of selects){
   const side=sel.dataset.pair.split('-')[1];
   const used=new Set(selects.filter(other=>other!==sel&&other.dataset.pair.split('-')[1]===side).map(other=>other.value).filter(Boolean));
   for(const opt of sel.options)if(opt.value)opt.disabled=used.has(opt.value);
  }
 };
 const refreshPreview=sel=>{
  const slot=sel.closest('.scs-team-pair-player')?.querySelector('.scs-team-pair-player-preview');
  if(!slot)return;
  slot.innerHTML=sel.value?playerRow(sel.value):'<span class="scs-team-pair-placeholder">Choose a player</span>';
  hydratePlayerCards();
 };
 selects.forEach(sel=>sel.addEventListener('change',()=>{refreshChoices();refreshPreview(sel)}));
 refreshChoices();hydratePlayerCards();
 modal.querySelector('[data-cancel]').onclick=()=>modal.remove();
 modal.querySelector('[data-save]').onclick=()=>{
  const pairs=e.matches.map(m=>[0,1].map(side=>[0,1].map(slot=>modal.querySelector('[data-pair="'+m.index+'-'+(side?'R':'L')+'-'+slot+'"]')?.value||'')));
  const left=pairs.flatMap(p=>p[0]),right=pairs.flatMap(p=>p[1]);
  if([...left,...right].some(x=>!x)||new Set(left.map(x=>x.toLowerCase())).size!==e.matches.length*2||new Set(right.map(x=>x.toLowerCase())).size!==e.matches.length*2){
   modal.querySelector('[data-error]').textContent='Select '+(e.matches.length*2)+' different players for each club, with no duplicates.';return;
  }
  if(e.matches.some((m,i)=>m.status!=='pending'&&JSON.stringify(m.pairs)!==JSON.stringify(pairs[i]))){
   modal.querySelector('[data-error]').textContent='Players cannot be changed after a match has been assigned or started.';return;
  }
  e.matches.forEach((m,i)=>m.pairs=pairs[i]);save();modal.remove();render();
 };
}
function assignTeamCourt(id,flow){
 if(viewOnly||!SCSEventCourtPool.ready(root()))return false;
 const m=allMatches().find(y=>y.id===id);
 if(!m||m.status!=='pending'||m.court||!Array.isArray(m.pairs)||m.pairs.length!==2||m.pairs.some(p=>p.length!==2||p.some(n=>!n)))return false;
 return SCSCourtAssignmentPopup.open({title:matchName(m),onClose:flow?.onClose,loadScoringPassword:()=>window.scsMatchScoringPassword('get',state._scsCloudTournamentId,m.id),saveScoringPassword:value=>window.scsMatchScoringPassword('set',state._scsCloudTournamentId,m.id,value),courts:SCSEventCourtPool.ids(state).map(n=>({number:n,occupied:allMatches().some(y=>y.court===n&&y.status!=='approved')})),onChoose:async n=>{
  if(viewOnly||m.status!=='pending'||m.court||!SCSEventCourtPool.ids(state).includes(n)||allMatches().some(y=>y.court===n&&y.status!=='approved'))return false;
  m.court=n;m.status='assigned';assigning=null;save();render();if(flow?.afterAssign)await flow.afterAssign();return true;
 }});
}
async function assignFromDashboard(item,onHome){
 if(viewOnly)throw Error('Court assignment access is required.');
 state=JSON.parse(JSON.stringify(item.state));rememberActiveEvent(item.event.id);state._scsTeamMainId=main._scsClientTournamentId||main.id;state._scsParentTournamentId=state._scsTeamMainId;state._scsClientTournamentId=state._scsClientTournamentId||item.event.id;
 mainMode=false;selectedEncounterId=null;tab='match';render();await SCSEventCourtPool.whenReady(root());
 const popup=assignTeamCourt(item.matchId,{onClose:()=>{save();onHome();},afterAssign:async()=>{const id=await SCSTournamentStore.save('team',state);if(!id)throw Error('Assignment saved on this device. Server sync is pending.');state._scsCloudTournamentId=id;save();}});
 if(!popup)throw Error('This match is no longer available. Refresh and try another match.');
}
function matchCard(m){
 const e=encounterFor(m),done=m.status==='approved',ready=m.pairs.every(p=>p.length===2);
 const pair=i=>m.pairs[i]||[];
 const base={number:m.id,title:clubName(e.a)+' vs '+clubName(e.b)+' · Doubles '+(m.index+1),left:pair(0).join(' / '),right:pair(1).join(' / '),leftPlayers:pair(0),rightPlayers:pair(1),score:scoreText(m),playerRenderer:teamMatchPlayer,winner:done?(m.winner==='L'?'left':m.winner==='R'?'right':null):null};
 // Preserve the existing SCS scored match card. Only pending header state and club identity differ.
 let card=SCSSharedMatchCenter.completed(base);
 if(!done){
  const status=ready?m.status.replace(/_/g,' '):'Select pairs';
  card=card.replace('<span class="scs-tm-completed-check">✓</span>','<span class="scs-team-pending-icon" aria-hidden="true">○</span>')
   .replace('</b></div><div class="scs-tm-completed-content">','</b><span class="scs-team-header-status">'+esc(status)+'</span></div><div class="scs-tm-completed-content">');
 }
 const assignAction=!viewOnly&&m.status==='pending'&&ready?'<button type="button" class="scs-gt-secondary scs-team-court-assign" data-assign="'+esc(m.id)+'">Assign Court</button>':'';
 return '<div class="scs-team-match-shell" '+(done&&!viewOnly?'role="button" tabindex="0" aria-label="Open saved scoreboard" ':'')+'style="--team-left:'+esc(clubAccent(e.a))+';--team-right:'+esc(clubAccent(e.b))+'" data-match-id="'+esc(m.id)+'">'+card+assignAction+'</div>';
}
function tournamentCourtChooser(){
 if(!assigning||viewOnly)return '';
 const m=allMatches().find(x=>x.id===assigning);
 if(!m||m.status!=='pending')return '';
 const courts=Array.from({length:state.courtCount},(_,i)=>{
  const n=SCSEventCourtPool.ids(state)[i],occupied=allMatches().some(x=>x.court===n&&x.status!=='approved');
  return '<button type="button" class="scs-gt-secondary" data-choose="'+n+'" '+(occupied?'disabled':'')+'>Court '+n+' · '+(occupied?'Occupied':'Free')+'</button>';
 }).join('');
 return '<div class="scs-gt-card scs-team-court-chooser" role="group" aria-label="Assign match to court"><strong>Assign '+esc(matchName(m))+' — Choose court</strong>'+courts+'<button type="button" data-cancel>Cancel</button></div>';
}
function fixtures(){
 if(!state.encounters.length)return '<section class="scs-gt-card scs-team-setup scs-team-fixture-setup"><h2>Generate club fixtures</h2><p>Confirm the tournament name, number of doubles matches, and club rosters in Clubs before generating fixtures.</p><p><strong>'+esc(state.title||'Tournament name not entered')+'</strong> · '+state.clubs.length+' clubs · '+state.matchesPerEncounter+' doubles per encounter</p>'+(viewOnly?'':'<button class="scs-gt-primary scs-team-generate" data-generate>Generate club fixtures →</button>')+'</section>';
 const selected=state.encounters.find(e=>e.id===selectedEncounterId);
 const tabs='<nav class="scs-team-encounter-tabs" aria-label="Club encounters"><button type="button" data-back-encounters class="'+(!selected?'active':'')+'" aria-current="'+(!selected?'page':'false')+'">All</button>'+(selected?'<button type="button" class="active" aria-current="page">'+esc(clubName(selected.a))+' vs '+esc(clubName(selected.b))+'</button>':'')+'<button type="button" data-team-section="ranking" class="'+(tab==='ranking'?'active':'')+'">Ranking</button><button type="button" data-team-section="matrix" class="'+(tab==='matrix'?'active':'')+'">Matrix</button></nav>';
 if(selected){const e=selected,done=e.matches.filter(m=>m.status==='approved'),a=done.filter(m=>m.winner==='L').length,b=done.filter(m=>m.winner==='R').length,winning=done.length===e.matches.length?(a>b?e.a:e.b):null;
  return '<section class="scs-team-fixtures scs-team-encounter-detail">'+tabs+'<h3>'+clubLabel(e.a)+' vs '+clubLabel(e.b)+'</h3><p class="scs-team-encounter-progress">'+a+' – '+b+' · '+done.length+'/'+e.matches.length+' completed</p>'+(viewOnly||done.length===e.matches.length?'':'<button class="scs-gt-secondary scs-team-pair-action" data-encounter="'+esc(e.id)+'">Select / Edit Pairs</button>')+e.matches.map(matchCard).join('')+(winning===null?'':'<div class="scs-team-encounter-winner" '+clubStyle(winning)+'>🏆 Encounter winner: '+esc(clubName(winning))+'</div>')+'</section>';
 }
 return '<section class="scs-team-fixtures scs-team-encounter-list">'+tabs+'<h3>Club encounters</h3>'+state.encounters.map(e=>{const done=e.matches.filter(m=>m.status==='approved'),a=done.filter(m=>m.winner==='L').length,b=done.filter(m=>m.winner==='R').length,finished=done.length===e.matches.length,started=e.matches.some(m=>m.status!=='pending');const status=finished?'completed':started?'live':'not-started';const label=finished?'COMPLETED':started?'LIVE':'NOT STARTED';const symbol=finished?'✓':started?'●':'◷';const action=finished?'View Results':started?'Continue':'Start';return '<button type="button" class="scs-team-encounter-card scs-team-encounter-'+status+'" data-open-encounter="'+esc(e.id)+'" style="--team-left:'+esc(clubAccent(e.a))+';--team-right:'+esc(clubAccent(e.b))+'"><span class="scs-team-encounter-card-status"><span aria-hidden="true">'+symbol+'</span> '+label+'</span><span class="scs-team-encounter-clubs"><strong>'+esc(clubName(e.a))+'</strong><span>VS</span><strong>'+esc(clubName(e.b))+'</strong></span><span class="scs-team-encounter-card-footer"><span>'+a+' – '+b+' · '+done.length+'/'+e.matches.length+' completed'+(finished?' · 🏆 '+esc(clubName(a>b?e.a:e.b))+' won':'')+'</span><strong>'+action+' →</strong></span></button>'}).join('')+'</section>';
}
function showMatrixEncounter(id){
 const r=root(),e=state.encounters.find(x=>x.id===id);if(!r||!e)return;
 r.querySelector('.scs-team-matrix-overlay')?.remove();
 const oldSelected=selectedEncounterId;selectedEncounterId=id;
 const existing=fixtures();selectedEncounterId=oldSelected;
 const overlay=document.createElement('div');overlay.className='scs-team-matrix-overlay';
 overlay.innerHTML='<div class="scs-team-matrix-backdrop" data-matrix-dismiss></div><section class="scs-team-matrix-bottom-sheet" role="dialog" aria-modal="true" aria-label="Encounter details"><div class="scs-team-matrix-sheet-head"><span class="scs-team-matrix-sheet-label" aria-hidden="true"></span><button type="button" data-matrix-dismiss aria-label="Close encounter details">✕</button></div><div class="scs-team-matrix-sheet-content">'+existing+'</div></section>';
 // Mount inside the existing Tournament sheet so its proven match-card styles and actions are inherited.
 r.querySelector('.scs-team-sheet').appendChild(overlay);
 // Apply the SAME post-render card decoration used by the Tournament encounter page.
 // Without this, the shared raw match-card HTML appears as a different design.
 decorateMatchCenter(overlay);
 hydratePlayerCards();
 const close=()=>{overlay.remove();document.removeEventListener('keydown',onKey)};
 const onKey=ev=>{if(ev.key==='Escape')close()};document.addEventListener('keydown',onKey);
 overlay.querySelectorAll('[data-matrix-dismiss]').forEach(b=>b.addEventListener('click',close));
 overlay.querySelectorAll('[data-encounter]').forEach(b=>b.addEventListener('click',()=>{close();editEncounter(b.dataset.encounter)}));
 overlay.querySelectorAll('.scs-team-match-shell[data-match-id]').forEach(el=>{
  const m=allMatches().find(x=>x.id===el.dataset.matchId);
  if(!m||!['approved','score_ready'].includes(m.status)||!m.score?.finished)return;
  const openSaved=()=>{if(!window.SCSScoring?.openTeamCompleted)return;const host=root();if(host)host.hidden=true;try{if(!SCSScoring.openTeamCompleted(m.id,m.score)&&host)host.hidden=false;else close()}catch(err){if(host)host.hidden=false;console.error(err)}};
  el.addEventListener('click',ev=>{if(!ev.target.closest('button,a,select,input'))openSaved()});
  el.addEventListener('keydown',ev=>{if(ev.key==='Enter'||ev.key===' '){ev.preventDefault();openSaved()}});
 });
 let startY=0;const sheet=overlay.querySelector('.scs-team-matrix-bottom-sheet');sheet.addEventListener('touchstart',ev=>{startY=ev.touches[0].clientY},{passive:true});sheet.addEventListener('touchend',ev=>{if(ev.changedTouches[0].clientY-startY>110&&sheet.querySelector('.scs-team-matrix-sheet-content').scrollTop===0)close()},{passive:true});
 overlay.querySelector('[data-matrix-dismiss].scs-team-matrix-sheet-head button')?.focus();
}
function scoreText(m){let sets=m.score?.completedSets||[];return sets.map(s=>(s.score||[]).join('–')).join(' | ')}
// Extend the shared Match Center locally; other tournament types keep their existing tabs.
function teamMatchPlayer(name){
 // Resolve against the selected clubs in this tournament only.
 const key=playerKey(name);
 const found=state.clubs.map((club,index)=>({
  club,index,
  player:(club.selectedPlayerDetails||[]).find(p=>playerKey(p.player||p.name)===key)
 })).find(x=>x.player)||state.clubs.map((club,index)=>({club,index})).find(x=>(x.club.players||[]).some(p=>playerKey(p)===key));
 const record=found&&found.player||{};
 const level=record.level??teamPlayerLevels.get(key)??teamLevel(name);
 const club=found&&found.club;
 const subClub=record.subClub||record.subclub||record.subClubName||club&&club.name||'';
 const accent=found?clubAccent(found.index):'#5279aa';
 return SCSSharedMatchCenter.playerIdentity(name,{level,gender:record.gender,subClub,accent});
}
function teamMatchCenterPanel(options){return SCSSharedMatchCenter.panel(options)}
function matchCenter(){
 let matches=selectedEncounterId?(state.encounters.find(e=>e.id===selectedEncounterId)?.matches||[]):allMatches(),courts=Array.from({length:state.courtCount},(_,i)=>{let n=SCSEventCourtPool.ids(state)[i],m=matches.find(x=>x.court===n&&x.status!=='approved');return m?{number:n,match:{status:m.status==='score_ready'?'SCORE READY':m.status.toUpperCase(),label:matchName(m),left:m.pairs[0],right:m.pairs[1],started:m.status!=='assigned',ready:m.status==='score_ready',score:scoreText(m),winner:m.winner==='L'?'left':m.winner==='R'?'right':null,action:viewOnly?'':m.status==='assigned'?'data-start="'+m.id+'"':m.status==='playing'?'data-score="'+m.id+'"':m.status==='score_ready'?'data-approve="'+m.id+'"':'',actionLabel:m.status==='assigned'?'Start Match':m.status==='playing'?'Score Match':'Approve Result'}}:{number:n}});courts.forEach(c=>{if(c.match)c.playerRenderer=teamMatchPlayer});return (selectedEncounterId?'<nav class="scs-team-encounter-tabs" aria-label="Club encounters"><button type="button" data-back-match-encounters>All</button><button type="button" class="active" aria-current="page">'+esc(clubName(state.encounters.find(e=>e.id===selectedEncounterId).a))+' vs '+esc(clubName(state.encounters.find(e=>e.id===selectedEncounterId).b))+'</button></nav>':'')+teamMatchCenterPanel({courtCount:state.courtCount,courts,tab:matchTab,hideRanking:true,assigning,ranking:'',underApproval:matches.filter(m=>m.status==='score_ready'&&m.score).map(m=>({number:m.id,title:matchName(m),left:m.pairs[0].join(' / '),right:m.pairs[1].join(' / '),leftPlayers:m.pairs[0],rightPlayers:m.pairs[1],playerRenderer:teamMatchPlayer,score:scoreText(m),winner:m.winner==='L'?'left':m.winner==='R'?'right':null,action:'data-team-approval-score="'+esc(m.id)+'"',actionLabel:'Edit Scoreboard'})),waiting:matches.filter(m=>m.court&&['assigned','playing','score_ready'].includes(m.status)&&Array.isArray(m.pairs)&&m.pairs.length===2&&m.pairs.every(p=>Array.isArray(p)&&p.length===2&&p.every(name=>typeof name==='string'&&name.trim()))).map(m=>({number:m.id,heading:matchName(m),left:m.pairs[0].join(' / '),right:m.pairs[1].join(' / '),label:'Court '+m.court,action:''})),completed:matches.filter(m=>m.status==='approved'&&m.score).map(m=>({number:m.id,title:matchName(m),left:m.pairs[0].join(' / '),right:m.pairs[1].join(' / '),leftPlayers:m.pairs[0],rightPlayers:m.pairs[1],playerRenderer:teamMatchPlayer,score:scoreText(m),winner:m.winner==='L'?'left':m.winner==='R'?'right':null,action:'data-team-completed-score="'+esc(m.id)+'"',actionLabel:'View Scoreboard'})),attrs:{change:n=>viewOnly?'disabled':'data-courts="'+n+'"',choose:n=>viewOnly?'disabled':'data-choose="'+n+'"',cancel:'data-cancel',tab:t=>'data-matchtab="'+t+'"'}})}
function decorateTeamCard(card,m){
 const e=encounterFor(m);if(!e)return;
 card.style.setProperty('--team-left',clubAccent(e.a));card.style.setProperty('--team-right',clubAccent(e.b));
 // V235: emphasize the doubles number, with matchup as a secondary subtitle.
 const heading=card.querySelector('.scs-tm-completed-title > b');
 if(heading && !heading.querySelector('.scs-team-doubles-heading')){
  heading.textContent='';
  const main=document.createElement('span');main.className='scs-team-doubles-heading';main.textContent='Doubles '+(m.index+1);
  const sub=document.createElement('small');sub.className='scs-team-match-subtitle';sub.textContent=clubName(e.a)+' vs '+clubName(e.b);
  heading.append(main,sub);
 }
 const teams=card.querySelectorAll('.scs-tm-completed-team');
 teams.forEach((team,i)=>{const id=i===0?e.a:e.b;team.querySelectorAll('.scs-team-card-club').forEach(label=>label.remove());team.classList.toggle('scs-team-losing-players',m.status==='approved'&&['L','R'].includes(m.winner)&&(i===(m.winner==='L'?1:0)));
  // V252: one compact club pill beside each player's name, within the existing row.
  team.querySelectorAll('.scs-tm-completed-players .scs-tm-serving-player').forEach(row=>{
   if(row.querySelector('.scs-match-player-identity'))return;
   if(row.querySelector('.scs-team-inline-club-pill'))return;
   const pill=document.createElement('span');pill.className='scs-team-inline-club-pill';pill.textContent=clubName(id)+' Club';
   pill.style.setProperty('--pill-accent',clubAccent(id));
   const player=row.querySelector('.scs-tm-shared-player');if(player)player.after(pill);else row.append(pill);
  })});
 const win=card.querySelector('.scs-tm-completed-winner');
 if(win&&m.winner){const id=winnerClub(m);win.classList.add('scs-team-neutral-winner');const b=win.querySelector('b');if(b)b.innerHTML=clubLabel(id)+' <span class="scs-team-winning-pair">'+esc(m.pairs[m.winner==='L'?0:1].join(' / '))+'</span>'}
}
function decorateMatchCenter(r){
 r.querySelectorAll('.scs-team-match-shell').forEach(shell=>{const m=allMatches().find(x=>String(x.id)===shell.dataset.matchId);if(m)decorateTeamCard(shell,m)});
 if(tab!=='match')return;
 // Keep the proven SCS panel/court controls, but use the exact same SCS card
 // for every Team Tournament match state, including waiting and assigned.
 r.querySelectorAll('.scs-tm-court-card:not(.is-free)').forEach(card=>{
  const label=card.querySelector('small');const m=label&&allMatches().find(x=>label.textContent===matchName(x));if(!m)return;
  const head=card.querySelector('.scs-tm-court-head')?.outerHTML||'';
  const action=card.querySelector('button[data-start],button[data-score],button[data-approve]')?.outerHTML||'';
  card.innerHTML=head+matchCard(m)+action;
 });
 if(tab==='match'){
  const pending=((selectedEncounterId&&state.encounters.find(e=>e.id===selectedEncounterId)?.matches)||allMatches()).filter(m=>m.status!=='approved'&&Array.isArray(m.pairs)&&m.pairs.length===2&&m.pairs.every(p=>Array.isArray(p)&&p.length===2&&p.every(name=>typeof name==='string'&&name.trim())));
  r.querySelectorAll('.scs-tm-live-center > .scs-tm-waiting-match').forEach((card,i)=>{
   const m=pending[i];if(!m)return;
   const action=card.querySelector('button[data-assign]')?.outerHTML||'';
   const status=m.court?'Court '+m.court:m.pairs.every(p=>p.length===2)?'Ready to assign':'Select pairs';
   card.outerHTML='<div class="scs-team-waiting-entry">'+matchCard(m)+(action||'<div class="scs-team-waiting-status">'+esc(status)+'</div>')+'</div>';
  });
 }
 if(false){
  const done=((selectedEncounterId&&state.encounters.find(e=>e.id===selectedEncounterId)?.matches)||allMatches()).filter(m=>m.status==='approved');
  r.querySelectorAll('.scs-tm-live-center > .scs-tm-completed-row').forEach((card,i)=>{if(done[i])card.outerHTML=matchCard(done[i])});
 }
 // Newly inserted cards also need the existing SCS player rings and club labels.
 r.querySelectorAll('.scs-team-match-shell').forEach(shell=>{const m=allMatches().find(x=>String(x.id)===shell.dataset.matchId);if(m)decorateTeamCard(shell,m)});
}

function tournamentReportTabs(active){
 const selected=state.encounters.find(e=>e.id===selectedEncounterId);
 return '<nav class="scs-team-encounter-tabs" aria-label="Tournament sections"><button type="button" data-team-section="fixtures">All</button>'+(selected?'<button type="button" data-team-section="selected">'+esc(clubName(selected.a))+' vs '+esc(clubName(selected.b))+'</button>':'')+'<button type="button" data-team-section="ranking" class="'+(active==='ranking'?'active':'')+'">Ranking</button><button type="button" data-team-section="matrix" class="'+(active==='matrix'?'active':'')+'">Matrix</button></nav>';
}
function mainHome(){
 restoreActiveEvent();
 return window.ScsApi.events.home({events:Array.isArray(main.events)?main.events:[],activeEventId,viewOnly});
}
// V286: The redundant Team Tournament overview page has been removed.
// Event navigation now goes directly to its existing setup/fixtures functions.
function clubsView(){
 if(!state.encounters.length)return setup();
 // Reuse the pre-fixture club card structure and CSS after fixtures are generated.
 // The previous post-creation markup used a different, unstyled horizontal layout.
 return '<section class="scs-gt-card scs-team-setup scs-team-clubs-view"><h2>Clubs</h2><p>Club rosters are shown here. Pair selection remains manual before each encounter.</p><div class="scs-team-club-list">'+state.clubs.map((c,i)=>'<div class="scs-team-club scs-team-club-color-'+clubColor(c,i)+'" style="--club-accent:'+esc(clubAccent(i))+'"><div class="scs-team-club-head"><button type="button" class="scs-team-expand" data-expand="'+i+'" aria-expanded="'+expandedClubs.has(i)+'" aria-label="Toggle '+esc(c.name)+' players">'+(expandedClubs.has(i)?'⌃':'⌄')+'</button><div class="scs-team-club-name"><strong>'+esc(c.name)+'</strong><small>'+c.players.length+' players</small></div></div>'+(expandedClubs.has(i)?'<div class="scs-team-roster">'+c.players.map((name,j)=>'<div class="scs-team-roster-player"><span class="scs-team-player-number">'+(j+1)+'</span>'+playerRow(name)+'</div>').join('')+'</div>':'')+'</div>').join('')+'</div></section>';
}
function teamBottomNav(){
 if(main&&main.events?.length&&!main.events.some(e=>e.id===activeEventId))restoreActiveEvent();
 const active=mainMode?'home':tab==='home'?'event':tab==='setup'||tab==='clubs'?'clubs':tab==='match'?'match':'tournament';
 return window.ScsApi.navigation.bottom({active,attribute:'data-team-nav',ariaLabel:'Team tournament sections',tournamentName:main?.title||'Tournament',eventName:main?.events?.find(e=>e.id===activeEventId)?.title||state.title||'Event'});
}
function render(){let r=root();if(!r)return;if(window.ScsApi?.tournamentAccess)ScsApi.tournamentAccess.attach(r,viewOnly);
 if(creatingEvent){
 r.innerHTML='<div class="scs-gt-sheet scs-team-sheet scs-team-create-sheet" role="dialog" aria-label="Add Team Tournament Event"><header><strong>'+esc(main.title)+'</strong><button type="button" data-event-cancel aria-label="Close">✕</button></header>'+eventNameForm()+'</div>';
 r.querySelectorAll('[data-event-cancel]').forEach(b=>b.onclick=close);
 r.querySelector('[data-event-create]').onclick=submitEvent;
 r.querySelector('[data-event-name]').addEventListener('keydown',e=>{if(e.key==='Enter')submitEvent()});
 r.querySelector('[data-event-name]').focus();
 return;
 }

 if(creatingMain){
 r.innerHTML='<div class="scs-gt-sheet scs-team-sheet scs-team-create-sheet" role="dialog" aria-label="Create Team Tournament"><header><strong>Team Tournament</strong><button type="button" data-main-cancel aria-label="Close">✕</button></header>'+mainNameForm()+'</div>';
 r.querySelectorAll('[data-main-cancel]').forEach(b=>b.onclick=close);
 r.querySelector('[data-main-create]').onclick=submitMain;
 r.querySelector('[data-main-name]').addEventListener('keydown',e=>{if(e.key==='Enter')submitMain()});
 r.querySelector('[data-main-name]').focus();
 return;
 }

 if(mainMode){if(r._scsEventCourtPool)r._scsEventCourtPool.active=false;
 window.ScsApi.events.mountHome(r,{title:main.title,courtDashboard:{id:main._scsClientTournamentId||main.id,aliases:[main.id,main._scsClientTournamentId],courtCount:main.courtCount||main.numCourts,format:'team',parentState:()=>main,storeCourtCount:(n,remote)=>{main.courtCount=n;if(remote)localStorage.setItem(MAIN_KEY,JSON.stringify(main));else persistMain();},returnHome:()=>open('edit'),storeEventState:(e,s)=>localStorage.setItem('scs_team_event_'+e.id,JSON.stringify(s)),loadEventState:e=>JSON.parse(localStorage.getItem('scs_team_event_'+e.id)||'null')},events:main.events||[],activeEventId,viewOnly,navAttribute:'data-team-nav',ariaLabel:'Team tournament sections'});
 r.querySelector('[data-close]').onclick=close;
 r.querySelector('[data-add-event]')?.addEventListener('click',addEvent);
 r.querySelectorAll('[data-open-event]').forEach(b=>b.onclick=()=>openEvent(b.dataset.openEvent));
 r.querySelectorAll('[data-team-nav]').forEach(b=>b.onclick=async()=>{const key=b.dataset.teamNav;if(key==='home'){render();return}const id=restoreActiveEvent();if(!id)return;await openEvent(id);if(key==='event')switchTeamTab('home');else if(key==='clubs')switchTeamTab(state.encounters.length?'clubs':'setup');else if(key==='tournament')switchTeamTab('fixtures');else if(key==='match')switchTeamTab('match')});
 return;
 }
if(['fixtures','match','matrix','ranking'].includes(tab)&&teamEventSetupIssues().length)tab='home';
const previousSheet=r.querySelector('.scs-team-sheet');if(previousSheet)teamScrollPositions[tab]=previousSheet.scrollTop;r.innerHTML='<div class="scs-gt-sheet scs-team-sheet"><header><strong>'+esc(state.title||'Team Tournament')+'</strong><div class="scs-team-save-actions"><button type="button" data-team-save '+(viewOnly?'disabled':'')+'>Save Tournament</button><button data-close aria-label="Close">✕</button></div></header><div class="scs-team-save-status" data-team-save-status role="status" aria-live="polite"></div>'+(tab==='home'?ScsApi.events.overview({name:state.title,parent:main?.title||state._scsParentTournamentTitle||'',format:'Team Tournament',teams:state.clubs.map(c=>c.name),matches:allMatches(),courts:state.courtCount,status:state.status})+'<details class="scs-overview-card"><summary>Club rosters · Details / Manage</summary>'+clubsView()+'</details>':tab==='setup'||tab==='clubs'?clubsView():tab==='match'?matchCenter():tab==='ranking'?tournamentReportTabs('ranking')+standings():tab==='matrix'?tournamentReportTabs('matrix')+matrix():fixtures())+'</div>'+teamBottomNav();const sheet=r.querySelector('.scs-team-sheet');if(sheet)sheet.scrollTop=teamScrollPositions[tab]||0;r.querySelector('[data-close]').onclick=close;r.querySelector('[data-team-save]')?.addEventListener('click',saveTeamTournamentNow);r.querySelectorAll('[data-team-section]').forEach(x=>x.onclick=()=>{
 const section=x.dataset.teamSection;
 if(section==='selected'&&!selectedEncounterId)return;
 if(section==='fixtures'){selectedEncounterId=null;switchTeamTab('fixtures');}
 else if(section==='selected')switchTeamTab('fixtures');
 else switchTeamTab(section);
});r.querySelectorAll('[data-team-nav]').forEach(x=>x.onclick=()=>{const key=x.dataset.teamNav;if(viewOnly&&key==='home'){close();return}if(key==='home'){if(main&&state._scsTeamMainId){saveEventIndex();mainMode=true;tab='home';render()}else switchTeamTab(state.encounters.length?'fixtures':'setup')}else if(key==='event')switchTeamTab('home');else if(key==='clubs')switchTeamTab(state.encounters.length?'clubs':'setup');else if(key==='tournament'){switchTeamTab('fixtures')}else if(key==='match')switchTeamTab('match')});r.querySelectorAll('[data-team-go]').forEach(x=>x.onclick=()=>{switchTeamTab(x.dataset.teamGo)});r.querySelector('#team-title')?.addEventListener('input',e=>{state.title=e.target.value;save()});r.querySelector('#team-match-count')?.addEventListener('change',e=>{const n=Number(e.target.value);if(![3,5,7,9].includes(n))return;state.matchesPerEncounter=n;save();render()});hydratePlayerCards();
refreshTeamEventGate();
if(!r._scsEventGateBound){r._scsEventGateBound=true;const refresh=()=>queueMicrotask(refreshTeamEventGate);r.addEventListener('input',refresh);r.addEventListener('change',refresh);}
decorateMatchCenter(r);hydratePlayerCards();
r.querySelector('[data-add]')?.addEventListener('click',()=>clubEditor(state.clubs.length));r.querySelectorAll('[data-matrix-encounter]').forEach(x=>x.addEventListener('click',()=>showMatrixEncounter(x.dataset.matrixEncounter)));r.querySelectorAll('[data-standing]').forEach(x=>x.addEventListener('click',()=>{const i=Number(x.dataset.standing);if(!Number.isInteger(i)||i<0||i>=state.clubs.length)return;expandedStandings.has(i)?expandedStandings.delete(i):expandedStandings.add(i);render()}));r.querySelectorAll('[data-expand]').forEach(x=>x.onclick=()=>{let i=Number(x.dataset.expand);expandedClubs.has(i)?expandedClubs.delete(i):expandedClubs.add(i);render()});r.querySelectorAll('[data-edit]').forEach(x=>x.onclick=()=>clubEditor(Number(x.dataset.edit)));r.querySelectorAll('[data-remove]').forEach(x=>x.onclick=()=>{if(state.encounters.length){alert('Club membership cannot be removed after fixtures have been generated.');return}if(!confirm('Remove this club and its roster from the tournament?'))return;state.clubs.splice(Number(x.dataset.remove),1);expandedClubs.clear();save();render()});r.querySelector('[data-generate]')?.addEventListener('click',generate);r.querySelectorAll('[data-open-encounter]').forEach(x=>x.onclick=()=>{selectedEncounterId=x.dataset.openEncounter;render();const sheet=root()?.querySelector('.scs-team-sheet');if(sheet)sheet.scrollTop=0;teamScrollPositions.fixtures=0});r.querySelector('[data-back-encounters]')?.addEventListener('click',()=>{selectedEncounterId=null;render();const sheet=root()?.querySelector('.scs-team-sheet');if(sheet)sheet.scrollTop=0;teamScrollPositions.fixtures=0});r.querySelectorAll('[data-open-match-encounter]').forEach(x=>x.onclick=()=>{selectedEncounterId=x.dataset.openMatchEncounter;teamScrollPositions.match=0;render()});r.querySelector('[data-back-match-encounters]')?.addEventListener('click',()=>{selectedEncounterId=null;teamScrollPositions.match=0;render()});r.querySelectorAll('[data-tab]').forEach(x=>x.onclick=()=>{switchTeamTab(x.dataset.tab)});r.querySelectorAll('[data-encounter]').forEach(x=>x.onclick=()=>editEncounter(x.dataset.encounter));r.querySelectorAll('[data-matchtab]').forEach(x=>x.onclick=()=>{rememberTeamScroll();matchTab=x.dataset.matchtab;render()});const selectedMatchTab=r.querySelector('.scs-tm-live-tabs button.active');if(selectedMatchTab)selectedMatchTab.scrollIntoView({block:'nearest',inline:'nearest'});r.querySelectorAll('[data-courts]').forEach(x=>x.onclick=()=>{const highestOccupied=Math.max(0,...allMatches().filter(m=>m.court&&m.status!=='approved').map(m=>Number(m.court)||0));state.courtCount=Math.max(1,highestOccupied,Math.min(12,state.courtCount+Number(x.dataset.courts)));save();render()});r.querySelectorAll('[data-assign]').forEach(x=>x.onclick=()=>assignTeamCourt(x.dataset.assign));r.querySelector('[data-cancel]')?.addEventListener('click',()=>{assigning=null;render()});r.querySelectorAll('[data-choose]').forEach(x=>x.onclick=()=>{let m=allMatches().find(y=>y.id===assigning),n=Number(x.dataset.choose);if(!m||m.status!=='pending')return;let occupying=allMatches().find(y=>y.court===n&&y.status!=='approved');if(occupying){alert('Court is occupied. Select a free court.');return}m.court=n;m.status='assigned';assigning=null;save();render()});r.querySelectorAll('[data-start]').forEach(x=>x.onclick=()=>{let m=allMatches().find(y=>y.id===x.dataset.start);m.status='playing';save();render()});r.querySelectorAll('.scs-team-match-shell[data-match-id]').forEach(x=>{
 const m=allMatches().find(y=>y.id===x.dataset.matchId);
 if(!m||!['approved','score_ready'].includes(m.status)||!m.score?.finished)return;
 const openSaved=()=>{if(!window.SCSScoring||!SCSScoring.openTeamCompleted){alert('Scoreboard is unavailable.');return;}const overlay=root();if(overlay)overlay.hidden=true;try{if(viewOnly||m.status==='approved')SCSScoring.openCompleted(m.score,()=>{if(overlay)overlay.hidden=false});else if(!SCSScoring.openTeamCompleted(m.id,m.score)&&overlay)overlay.hidden=false;}catch(err){if(overlay)overlay.hidden=false;console.error(err);alert('Could not open saved scoreboard.');}};
 x.addEventListener('click',e=>{if(e.target.closest('button,a,select,input'))return;openSaved()});
 x.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openSaved()}});
 });r.querySelectorAll('[data-team-approval-score],[data-team-completed-score]').forEach(x=>x.onclick=()=>{const m=allMatches().find(y=>String(y.id)===String(x.dataset.teamApprovalScore||x.dataset.teamCompletedScore));if(!m?.score||!window.SCSScoring)return;const overlay=root();if(overlay)overlay.hidden=true;try{const ok=(viewOnly||m.status==='approved')?SCSScoring.openCompleted(m.score,()=>{if(overlay)overlay.hidden=false}):SCSScoring.openTeamCompleted(m.id,m.score);if(ok===false&&overlay)overlay.hidden=false}catch(err){if(overlay)overlay.hidden=false;console.error(err)}});r.querySelectorAll('[data-score]').forEach(x=>x.onclick=()=>{let m=allMatches().find(y=>y.id===x.dataset.score);if(!m||m.status!=='playing'||!m.court)return;if(!window.SCSScoring||!SCSScoring.openGroupMatch){alert('Scoreboard is unavailable.');return;}const overlay=root();if(overlay)overlay.hidden=true;try{SCSScoring.openGroupMatch({sessionId:'local-team-'+m.id,round:1,court:m.court,pair1:m.pairs[0],pair2:m.pairs[1],courtCenter:true,groupId:m.id})}catch(error){if(overlay)overlay.hidden=false;console.error('Team match scoring:',error);alert('Could not open the scoreboard.')}});r.querySelectorAll('[data-approve]').forEach(x=>x.onclick=()=>finishConductMatch(x.dataset.approve));}
function scoreUpdate(id,score,winner){if(viewOnly)return false;let m=allMatches().find(x=>x.id===id);if(!m||!['playing','score_ready'].includes(m.status))return false;m.score=score;if(winner){m.winner=winner;m.status='score_ready'}save();render();return true}
async function updateCompletedScore(id,score,winner){
 const m=allMatches().find(x=>x.id===id);
 if(!m||m.status!=='score_ready'||viewOnly||!score?.finished||!['L','R'].includes(winner))return false;
 if(!window.SCSTournamentStore||typeof window.SCSTournamentStore.save!=='function')return false;
 const previousScore=m.score,previousWinner=m.winner;
 m.score=score;m.winner=winner;
 try{
  // A successful cloud write is required before the scoreboard reports success.
  const cloudId=await window.SCSTournamentStore.save('team',state);
  if(!cloudId)throw new Error('Tournament score was not saved to Supabase');
  state._scsCloudTournamentId=cloudId;
  save();render();return true;
 }catch(error){
  m.score=previousScore;m.winner=previousWinner;
  console.error('Team scoreboard cloud save failed:',error);
  return false;
 }
}
function conductMatches(){if(viewOnly)return [];return allMatches().filter(m=>m.court&&['playing','score_ready'].includes(m.status)).map(m=>({id:m.id,court:m.court,status:m.status,pair1:m.pairs[0],pair2:m.pairs[1],score:m.score,winner:m.winner,label:matchName(m)}));}
async function finishConductMatch(id){if(viewOnly)return false;const m=allMatches().find(x=>x.id===id);if(!m||m.status!=='score_ready'||!m.score?.finished||!['L','R'].includes(m.winner))return false;try{if(!window.SCSTournamentEngine)throw Error('Tournament engine is unavailable.');const approved=await SCSTournamentEngine.run('approve-result',{score:m.score,winner:m.winner});m.status=approved.status}catch(error){alert(error.message||'Could not approve this result.');return false}m.court=null;workerTeamStandings=null;await refreshWorkerTeamStandings(false);save();render();return true}
// Shared registered-club roster picker for knockout and team tournaments.
// Team Tournament supplies its registered-club data to the canonical shared picker.
function pickRegisteredRoster(onDone){
 return window.ScsApi.players.pickRegisteredRoster(onDone,{
  registeredClubChoices,registeredClubPlayers,playerRow,hydratePlayerCards
 });
}
// Canonical shared API. The old global is a compatibility alias, not a second implementation.
const teamApi={assignFromDashboard,
  pickRegisteredRoster, open, close, scoreUpdate, updateCompletedScore,
  conductMatches, finishConductMatch, playersManagerReturned,
  returnFromScore(){if(root())root().hidden=false}, getState(){if(!viewOnly)load();return JSON.parse(JSON.stringify(state))},
  pages:{home:mainHome, clubs:clubsView, tournament:fixtures, matchCenter:matchCenter},
  cards:{player:playerRow, match:matchCard},
  ui:{render, switchTab:switchTeamTab, hydratePlayerCards},
  events:{open:openEvent, add:addEvent, create:submitEvent, restoreActive:restoreActiveEvent},
  roster:{registeredClubChoices, registeredClubPlayers},
  storage:{save, load}
};
window.ScsApi=window.ScsApi||{};
window.ScsApi.team=teamApi;
window.ScsApi.matchCenter.team=matchCenter;
window.ScsApi.players=window.ScsApi.players||{};

function receiveRemoteScores(row){if(mainMode||!row?.state||!(row.id===state._scsCloudTournamentId||row.state._scsClientTournamentId&&row.state._scsClientTournamentId===state._scsClientTournamentId))return false;if(!window.SCSTournamentScores?.merge('team',state,row.state))return false;localStorage.setItem(KEY,JSON.stringify(state));if(root()&&!root().hidden)render();return true;}
teamApi.receiveRemoteScores=receiveRemoteScores;
window.SCSTeamTournament=teamApi;

"pickRegisteredRoster".split(" ").forEach(function(name){var original=window.SCSTeamTournament[name];if(typeof original==='function')window.SCSTeamTournament[name]=function(){if(viewOnly)return false;return original.apply(this,arguments)}});
})();
